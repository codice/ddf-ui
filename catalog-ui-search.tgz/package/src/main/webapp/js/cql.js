import { __assign } from "tslib";
/**
 * Copyright (c) Codice Foundation
 *
 * This is free software: you can redistribute it and/or modify it under the terms of the GNU Lesser
 * General Public License as published by the Free Software Foundation, either version 3 of the
 * License, or any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details. A copy of the GNU Lesser General Public License
 * is distributed along with this program and can be found at
 * <http://www.gnu.org/licenses/lgpl.html>.
 *
 **/
/* Copyright (c) 2006-2015 by OpenLayers Contributors (see authors.txt for
 * full list of contributors). Published under the 2-clause BSD license.
 * See license.txt in the OpenLayers distribution or repository for the
 * full text of the license. */
import { CQLStandardFilterBuilderClass, deserialize, FilterBuilderClass, FilterClass, isBasicDatatypeClass, isFilterBuilderClass, isCQLStandardFilterBuilderClass, serialize, shouldBeFilterBuilderClass, convertResourceSizeFilterClassValueToBytes, isResourceSizeFilterClass, isResourceSizeRangeFilterClass, convertResourceSizeRangeFilterClassValueToBytes, } from '../component/filter-builder/filter.structure';
import { getDataTypesConfiguration } from '../component/reserved-basic-datatype/reserved.basic-datatype';
import CQLUtils from './CQLUtils';
import _cloneDeep from 'lodash/cloneDeep';
import wkx from 'wkx';
import { StartupDataStore } from './model/Startup/startup';
import Extensions from '../extension-points';
var getPointRadiusFilter = function (point, property, radius) {
    var value = {
        mode: 'circle',
        type: 'POINTRADIUS',
        lat: point[1],
        lon: point[0],
    };
    return new FilterClass({
        type: 'GEOMETRY',
        value: (radius ? __assign(__assign({}, value), { radius: radius }) : value),
        property: property,
    });
};
var getLinestringFilter = function (line, property, buffer) {
    var value = {
        mode: 'line',
        type: 'LINE',
        line: line,
    };
    return new FilterClass({
        type: 'GEOMETRY',
        value: (buffer
            ? __assign(__assign({}, value), { lineWidth: buffer }) : value),
        property: property,
    });
};
var getPolygonFilter = function (poly, property, buffer) {
    var value = {
        mode: 'poly',
        type: 'POLYGON',
        polygon: poly,
    };
    return new FilterClass({
        type: 'GEOMETRY',
        value: (buffer
            ? __assign(__assign({}, value), { polygonBufferWidth: buffer }) : value),
        property: property,
    });
};
var ANYTEXT_WILDCARD = '"anyText" ILIKE \'%\'';
var timePattern = /((([0-9]{4})(-([0-9]{2})(-([0-9]{2})(T([0-9]{2}):([0-9]{2})(:([0-9]{2})(\.([0-9]+))?)?(Z|(([-+])([0-9]{2}):([0-9]{2})))?)?)?)?)|^'')/i, patterns = {
    //Allows for non-standard single-quoted property names
    PROPERTY: /^([_a-zA-Z]\w*|"[^"]+"|'[^']+')/,
    COMPARISON: /^(=|<>|<=|<|>=|>|LIKE|ILIKE)/i,
    IS_NULL: /^IS NULL/i,
    COMMA: /^,/,
    LOGICAL: /^(AND|OR)/i,
    VALUE: /^('([^']|'')*'|-?\d+(\.\d*)?|\.\d+)/,
    FILTER_FUNCTION: /^[a-z]\w+\(/,
    BOOLEAN: /^(false|true)/i,
    LPAREN: /^\(/,
    RPAREN: /^\)/,
    SPATIAL: /^(BBOX|INTERSECTS|DWITHIN|WITHIN|CONTAINS)/i,
    UNITS: /^(meters)/i,
    NOT: /^NOT/i,
    BETWEEN: /^BETWEEN/i,
    BEFORE: /^BEFORE/i,
    AFTER: /^AFTER/i,
    DURING: /^DURING/i,
    RELATIVE: /^'RELATIVE\([A-Za-z0-9.]*\)'/i,
    TIME: new RegExp('^' + timePattern.source),
    TIME_PERIOD: new RegExp('^' + timePattern.source + '/' + timePattern.source),
    GEOMETRY: function (text) {
        var type = /^(POINT|LINESTRING|POLYGON|MULTIPOINT|MULTILINESTRING|MULTIPOLYGON|GEOMETRYCOLLECTION)/.exec(text);
        if (type) {
            var len = text.length;
            var idx = text.indexOf('(', type[0].length);
            if (idx > -1) {
                var depth = 1;
                while (idx < len && depth > 0) {
                    idx++;
                    switch (text.charAt(idx)) {
                        case '(':
                            depth++;
                            break;
                        case ')':
                            depth--;
                            break;
                        default:
                        // in default case, do nothing
                    }
                }
            }
            return [text.substr(0, idx + 1)];
        }
        return null;
    },
    END: /^$/,
}, follows = {
    ROOT_NODE: [
        'NOT',
        'GEOMETRY',
        'SPATIAL',
        'FILTER_FUNCTION',
        'PROPERTY',
        'LPAREN',
    ],
    LPAREN: [
        'NOT',
        'GEOMETRY',
        'SPATIAL',
        'FILTER_FUNCTION',
        'PROPERTY',
        'VALUE',
        'LPAREN',
    ],
    RPAREN: ['NOT', 'LOGICAL', 'END', 'RPAREN', 'COMPARISON', 'COMMA'],
    PROPERTY: [
        'COMPARISON',
        'BETWEEN',
        'COMMA',
        'IS_NULL',
        'BEFORE',
        'AFTER',
        'DURING',
        'RPAREN',
    ],
    BETWEEN: ['VALUE'],
    IS_NULL: ['RPAREN', 'LOGICAL', '[', ']'],
    COMPARISON: ['RELATIVE', 'VALUE', 'BOOLEAN'],
    COMMA: ['FILTER_FUNCTION', 'GEOMETRY', 'VALUE', 'UNITS', 'PROPERTY'],
    VALUE: ['LOGICAL', 'COMMA', 'RPAREN', 'END'],
    BOOLEAN: ['RPAREN'],
    SPATIAL: ['LPAREN'],
    UNITS: ['RPAREN'],
    LOGICAL: [
        'FILTER_FUNCTION',
        'NOT',
        'VALUE',
        'SPATIAL',
        'PROPERTY',
        'LPAREN',
    ],
    NOT: ['PROPERTY', 'LPAREN'],
    GEOMETRY: ['COMMA', 'RPAREN'],
    BEFORE: ['TIME'],
    AFTER: ['TIME'],
    DURING: ['TIME_PERIOD'],
    TIME: ['LOGICAL', 'RPAREN', 'END'],
    TIME_PERIOD: ['LOGICAL', 'RPAREN', 'END'],
    RELATIVE: ['RPAREN', 'END'],
    FILTER_FUNCTION: ['LPAREN', 'PROPERTY', 'VALUE', 'RPAREN'],
    END: [],
}, precedence = {
    RPAREN: 3,
    LOGICAL: 2,
    COMPARISON: 1,
}, 
// as an improvement, these could be figured out while building the syntax tree
filterFunctionParamCount = {
    proximity: 3,
    pi: 0,
}, dateTimeFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
function tryToken(text, pattern) {
    if (pattern instanceof RegExp) {
        return pattern.exec(text);
    }
    else {
        return pattern(text);
    }
}
function nextToken(text, tokens) {
    var i, token, len = tokens.length;
    for (i = 0; i < len; i++) {
        token = tokens[i];
        var pat = patterns[token];
        var matches = tryToken(text, pat);
        if (matches) {
            var match = matches[0];
            var remainder = text.substr(match.length).replace(/^\s*/, '');
            return {
                type: token,
                text: match,
                remainder: remainder,
            };
        }
    }
    var msg = 'ERROR: In parsing: [' + text + '], expected one of: ';
    for (i = 0; i < len; i++) {
        token = tokens[i];
        msg += '\n    ' + token + ': ' + patterns[token];
    }
    throw new Error(msg);
}
function tokenize(text) {
    var results = [];
    var token = undefined;
    var expect = follows['ROOT_NODE'];
    do {
        token = nextToken(text, expect);
        text = token.remainder;
        expect = follows[token.type];
        if (token.type !== 'END' && !expect) {
            throw new Error('No follows list for ' + token.type);
        }
        results.push(token);
    } while (token.type !== 'END');
    return results;
}
// Mapping of Intrigue's query language syntax to CQL syntax
var userqlToCql = {
    '*': '%',
    '?': '_',
    '%': '\\%',
    _: '\\_',
};
var translateUserqlToCql = function (str) {
    return str.replace(/([^*?%_])?([*?%_])/g, function (_, a, b) {
        if (a === void 0) { a = ''; }
        return a + (a === '\\' ? b : userqlToCql[b]);
    });
};
//Mapping of CQL syntax to Intrigue's query language syntax
var cqlToUserql = {
    '%': '*',
    _: '?',
};
var translateCqlToUserql = function (str) {
    return str.replace(/([^%_])?([%_])/g, function (_, a, b) {
        if (a === void 0) { a = ''; }
        return a === '\\' ? b : a + cqlToUserql[b];
    });
};
var getNextToken = function (postfix) {
    if (postfix[postfix.length - 3] &&
        postfix[postfix.length - 3].type === 'FILTER_FUNCTION') {
        // first two are useless
        postfix.pop();
        postfix.pop();
        return postfix.pop();
    }
    if (postfix[postfix.length - 2] &&
        postfix[postfix.length - 2].type === 'RELATIVE') {
        // first one is useless
        postfix.pop();
        return postfix.pop();
    }
    return postfix.pop();
};
var getGeoFilters = function (wkt, property, buffer) {
    if (wkt.startsWith('GEOMETRYCOLLECTION')) {
        var parsedWkt = wkx.Geometry.parse(wkt);
        var geoJson = parsedWkt.toGeoJSON();
        var innerWkts = geoJson.geometries.map(function (geometry) {
            return wkx.Geometry.parseGeoJSON(geometry).toWkt();
        });
        return new FilterBuilderClass({
            type: 'OR',
            filters: innerWkts.map(function (wkt) { return getGeoFilters(wkt, property, buffer); }),
        });
    }
    else if (wkt.startsWith('LINESTRING')) {
        var line = CQLUtils.arrayFromLinestringWkt(wkt);
        return getLinestringFilter(line, property, buffer);
    }
    else if (wkt.startsWith('MULTILINESTRING')) {
        return new FilterBuilderClass({
            type: 'OR',
            filters: CQLUtils.arrayFromMultilinestringWkt(wkt).map(function (line) { return getLinestringFilter(line, property, buffer); }),
        });
    }
    else if (wkt.startsWith('POLYGON')) {
        var poly = CQLUtils.arrayFromPolygonWkt(wkt);
        return getPolygonFilter(poly, property, buffer);
    }
    else if (wkt.startsWith('MULTIPOLYGON')) {
        return new FilterBuilderClass({
            type: 'OR',
            filters: CQLUtils.arrayFromPolygonWkt(wkt).map(function (poly) {
                return getPolygonFilter(poly, property, buffer);
            }),
        });
    }
    else if (wkt.startsWith('POINT')) {
        var point = CQLUtils.arrayFromPointWkt(wkt)[0];
        return getPointRadiusFilter(point, property, buffer);
    }
    else if (wkt.startsWith('MULTIPOINT')) {
        return new FilterBuilderClass({
            type: 'OR',
            filters: CQLUtils.arrayFromPointWkt(wkt).map(function (point) {
                return getPointRadiusFilter(point, property, buffer);
            }),
        });
    }
    throw new Error('Unknown spatial type encountered');
};
function buildTree(postfix) {
    var value, property, tok = getNextToken(postfix);
    var tokenType = tok.type;
    switch (tokenType) {
        case 'LOGICAL':
            var rhs = buildTree(postfix), lhs = buildTree(postfix);
            return new FilterBuilderClass({
                filters: [lhs, rhs],
                type: tok.text.toUpperCase(),
            });
        case 'NOT':
            var peekToken = postfix[postfix.length - 1];
            if (peekToken.type === 'LOGICAL') {
                return new FilterBuilderClass(__assign(__assign({}, buildTree(postfix)), { negated: true }));
            }
            else if (peekToken.type === 'NOT') {
                return new FilterBuilderClass({
                    filters: [buildTree(postfix)],
                    type: 'AND',
                    negated: true,
                });
            }
            else {
                return new FilterClass(__assign(__assign({}, buildTree(postfix)), { negated: true }));
            }
        case 'BETWEEN': // works
            var min = void 0, max = void 0;
            postfix.pop(); // unneeded AND token here
            max = buildTree(postfix);
            min = buildTree(postfix);
            property = buildTree(postfix);
            return new FilterClass({
                property: property,
                value: {
                    start: min,
                    end: max,
                },
                type: tokenType,
            });
        case 'BEFORE': // works
        case 'AFTER': // works
            value = buildTree(postfix);
            property = buildTree(postfix);
            return new FilterClass({
                property: property,
                value: value,
                type: tok.text.toUpperCase(),
            });
        case 'DURING': // technically between for dates, works
            var dates = buildTree(postfix).split('/');
            property = buildTree(postfix);
            return new FilterClass({
                property: property,
                value: {
                    start: dates[0],
                    end: dates[1],
                },
                type: tok.text.toUpperCase(),
            });
        case 'COMPARISON': // works
            value = buildTree(postfix);
            property = buildTree(postfix);
            return new FilterClass({
                property: property,
                value: value,
                type: tok.text.toUpperCase(),
            });
        case 'IS_NULL': // works
            property = buildTree(postfix);
            return new FilterClass({
                property: property,
                type: tok.text.toUpperCase(),
            });
        case 'VALUE': //works
            var match = tok.text.match(/^'(.*)'$/);
            if (match) {
                if (unwrap(postfix[0].text) === 'id') {
                    // don't escape ids
                    return match[1].replace(/''/g, "'");
                }
                else {
                    return translateCqlToUserql(match[1].replace(/''/g, "'"));
                }
            }
            else {
                return Number(tok.text);
            }
        case 'BOOLEAN': // works
            switch (tok.text.toUpperCase()) {
                case 'TRUE':
                    return true;
                default:
                    return false;
            }
        case 'SPATIAL': // working
            // next token tells us whether this is DWITHIN or INTERSECTS
            switch (tok.text) {
                case 'INTERSECTS': {
                    // things without buffers, could be poly or line
                    var valueToken = postfix.pop();
                    var propertyToken = postfix.pop();
                    return getGeoFilters(valueToken.text, propertyToken.text, undefined);
                }
                case 'DWITHIN': {
                    // things with buffers, could be poly, line or point
                    var bufferToken = postfix.pop();
                    var valueToken = postfix.pop();
                    var propertyToken = postfix.pop();
                    return getGeoFilters(valueToken.text, propertyToken.text, bufferToken.text);
                }
                default:
                    throw new Error('Unknown spatial type encountered');
            }
        case 'GEOMETRY':
            return {
                type: tokenType,
                value: tok.text,
            };
        case 'RELATIVE':
            return new FilterClass({
                type: 'RELATIVE',
                value: deserialize.dateRelative(tok.text),
                property: postfix.pop().text,
            });
        case 'FILTER_FUNCTION': // working
            var filterFunctionName = tok.text.slice(0, -1); // remove trailing '('
            var paramCount = filterFunctionParamCount[filterFunctionName];
            if (paramCount === undefined) {
                throw new Error('Unsupported filter function: ' + filterFunctionName);
            }
            var params = Array.apply(null, Array(paramCount))
                .map(function () { return buildTree(postfix); })
                .reverse();
            switch (filterFunctionName) {
                case 'proximity':
                    var proximityStrings = params[2];
                    return new FilterClass({
                        type: 'FILTER FUNCTION proximity',
                        property: params[0],
                        value: {
                            first: proximityStrings.split(' ')[0],
                            second: proximityStrings.split(' ')[1],
                            distance: params[1],
                        },
                    });
                default:
                    throw new Error('Unknown filter function');
            }
        case 'TIME_PERIOD':
            return tok.text;
        default:
            return tok.text;
    }
}
function buildAst(tokens) {
    var operatorStack = [], postfix = [];
    while (tokens.length) {
        var tok = tokens.shift();
        switch (tok.type) {
            case 'PROPERTY':
                tok.text = unwrap(tok.text);
            case 'GEOMETRY':
            case 'VALUE':
            case 'TIME':
            case 'TIME_PERIOD':
            case 'RELATIVE':
            case 'BOOLEAN':
                postfix.push(tok);
                break;
            case 'COMPARISON':
            case 'BETWEEN':
            case 'IS_NULL':
            case 'LOGICAL':
            case 'BEFORE':
            case 'AFTER':
            case 'DURING':
                var p = precedence[tok.type];
                while (operatorStack.length > 0 &&
                    precedence[operatorStack[operatorStack.length - 1].type] <= p) {
                    postfix.push(operatorStack.pop());
                }
                operatorStack.push(tok);
                break;
            case 'SPATIAL':
            case 'NOT':
            case 'LPAREN':
                operatorStack.push(tok);
                break;
            case 'FILTER_FUNCTION':
                operatorStack.push(tok);
                // insert a '(' manually because we lost the original LPAREN matching the FILTER_FUNCTION regex
                operatorStack.push({ type: 'LPAREN' });
                break;
            case 'RPAREN':
                while (operatorStack.length > 0 &&
                    operatorStack[operatorStack.length - 1].type !== 'LPAREN') {
                    postfix.push(operatorStack.pop());
                }
                operatorStack.pop(); // toss out the LPAREN
                // if this right parenthesis ends a function argument list (it's not for a logical grouping),
                // it's now time to add that function to the postfix-ordered list
                var lastOperatorType = operatorStack.length > 0 &&
                    operatorStack[operatorStack.length - 1].type;
                if (lastOperatorType === 'SPATIAL' ||
                    lastOperatorType === 'FILTER_FUNCTION') {
                    postfix.push(operatorStack.pop());
                }
                break;
            case 'COMMA':
            case 'END':
            case 'UNITS':
                break;
            default:
                throw new Error('Unknown token type ' + tok.type);
        }
    }
    while (operatorStack.length > 0) {
        postfix.push(operatorStack.pop());
    }
    var result = buildTree(postfix);
    if (postfix.length > 0) {
        var msg = 'Remaining tokens after building AST: \n';
        for (var i = postfix.length - 1; i >= 0; i--) {
            msg += postfix[i].type + ': ' + postfix[i].text + '\n';
        }
        throw new Error(msg);
    }
    return result;
}
function wrap(property) {
    var wrapped = property;
    if (!wrapped.startsWith('"')) {
        wrapped = '"' + wrapped;
    }
    if (!wrapped.endsWith('"')) {
        wrapped = wrapped + '"';
    }
    return wrapped;
}
function unwrap(property) {
    // Remove single and double quotes if they exist in property name
    return property.replace(/^'|'$/g, '').replace(/^"|"$/g, '');
}
// really could use some refactoring to enable better typing, right now it's recursive and calls itself with so many different types / return types
function write(filter) {
    switch (filter.type) {
        // spatialClass
        case 'BBOX':
            var xmin = filter.value[0], ymin = filter.value[1], xmax = filter.value[2], ymax = filter.value[3];
            return ('BBOX(' +
                wrap(filter.property) +
                ',' +
                xmin +
                ',' +
                ymin +
                ',' +
                xmax +
                ',' +
                ymax +
                ')');
        // verified line, polygon, point radius
        case 'DWITHIN':
            return "DWITHIN(".concat(wrap(filter.property), ", ").concat(filter.value, ", ").concat(filter.distance, ", meters)");
        // unused at the moment
        case 'WITHIN':
            return ('WITHIN(' + wrap(filter.property) + ', ' + write(filter.value) + ')');
        // verified bbox
        case 'INTERSECTS':
            return 'INTERSECTS(' + wrap(filter.property) + ', ' + filter.value + ')';
        // unused at the moment
        case 'CONTAINS':
            return ('CONTAINS(' + wrap(filter.property) + ', ' + write(filter.value) + ')');
        // all "geo" filters pass through this first, which serializes them into a form that cql understands
        // this is only done here on the fly because the transformation involves a loss of information
        // (such as the units [meters or miles?] and coordinate system [dms or mgrs?])
        case 'GEOMETRY':
            return write(serialize.location(filter.property, filter.value));
        // logicalClass
        case 'AND':
        case 'OR':
            var res = '(';
            var first = true;
            for (var i = 0; i < filter.filters.length; i++) {
                var writtenFilter = write(filter.filters[i]);
                if (writtenFilter) {
                    if (first) {
                        first = false;
                    }
                    else {
                        res += ') ' + filter.type + ' (';
                    }
                    res += writtenFilter;
                }
            }
            return res + ')';
        case 'NOT':
            // TODO: deal with precedence of logical operators to
            // avoid extra parentheses (not urgent)
            return 'NOT (' + write(filter.filters[0]) + ')';
        // comparisonClass
        case 'IS NULL':
            return "(\"".concat(filter.property, "\" ").concat(filter.type, ")");
        case 'BETWEEN':
            return (wrap(filter.property) +
                ' BETWEEN ' +
                write(Math.min(filter.value.start, filter.value.end)) +
                ' AND ' +
                write(Math.max(filter.value.start, filter.value.end)));
        case '=':
        case '<>':
        case '<':
        case '<=':
        case '>':
        case '>=':
        case 'LIKE':
        case 'ILIKE':
            var property = typeof filter.property === 'object'
                ? write(filter.property)
                : wrap(unwrap(filter.property)); // unwrap first, because technically only "" is supported (so swap '' for "")
            if (filter.value === null) {
                return "".concat(property, " ").concat(filter.type);
            }
            return "".concat(property, " ").concat(filter.type, " ").concat(unwrap(filter.property) === 'id'
                ? "'".concat(filter.value, "'")
                : write(filter.value)); // don't escape ids
        // temporalClass
        case 'RELATIVE':
            // weird thing I noticed is you have to wrap the value in single quotes, double quotes don't work
            return "".concat(wrap(filter.property), " = '").concat(serialize.dateRelative(filter.value), "'");
        case 'AROUND':
            return "".concat(wrap(filter.property), " ").concat(serialize.dateAround(filter.value));
        case 'BEFORE':
        case 'AFTER':
            return (wrap(filter.property) +
                ' ' +
                filter.type +
                ' ' +
                (filter.value ? filter.value.toString(dateTimeFormat) : "''"));
        case 'DURING':
            return "".concat(wrap(filter.property), " ").concat(filter.type, " ").concat(filter.value.start, "/").concat(filter.value.end);
        // filterFunctionClass
        case 'FILTER FUNCTION proximity':
            // not sure why we need the = true part but without it the backend fails to parse
            return "proximity(".concat(write(filter.property), ",").concat(write(filter.value.distance), ",").concat(write("".concat(filter.value.first, " ").concat(filter.value.second)), ") = true");
            break;
        case 'BOOLEAN_TEXT_SEARCH':
            var booleanTextSearchFilter = filter.value;
            if (booleanTextSearchFilter.error) {
                return;
            }
            else if (booleanTextSearchFilter.cql === '') {
                return "(anyText ILIKE '*')";
            }
            else {
                return booleanTextSearchFilter.cql;
            }
            break;
        case undefined:
            if (typeof filter === 'string') {
                return translateUserqlToCql("'" + filter.replace(/'/g, "''") + "'");
            }
            else if (typeof filter === 'number') {
                return String(filter);
            }
            else if (typeof filter === 'boolean') {
                return Boolean(filter);
            }
            break;
        default:
            throw new Error("Can't encode: " + filter.type + ' ' + filter);
    }
}
function simplifyFilters(cqlAst) {
    for (var i = 0; i < cqlAst.filters.length; i++) {
        if (simplifyAst(cqlAst.filters[i], cqlAst)) {
            cqlAst.filters.splice.apply(cqlAst.filters, [i, 1].concat(cqlAst.filters[i].filters));
        }
    }
    return cqlAst;
}
/**
 * The current read function for cql produces an unoptimized tree.  While it's possible we could
 * fix the output there, I'm not sure of how.  It ends up producing very nested filter trees from
 * relatively simple cql.
 * @param cqlAst
 * @param parentNode
 */
function simplifyAst(cqlAst, parentNode) {
    if (!isFilterBuilderClass(cqlAst) && parentNode) {
        return false;
    }
    else if (!parentNode) {
        if (isFilterBuilderClass(cqlAst)) {
            simplifyFilters(cqlAst);
        }
        return cqlAst;
    }
    else {
        simplifyFilters(cqlAst);
        if (cqlAst.type === parentNode.type && !cqlAst.negated) {
            // these are the only simplifications we can make based on boolean algebra rules
            return true;
        }
        else {
            return false;
        }
    }
}
function uncollapseNOTs(_a) {
    var cqlAst = _a.cqlAst;
    if (isFilterBuilderClass(cqlAst)) {
        if (cqlAst.negated) {
            return new CQLStandardFilterBuilderClass({
                type: 'NOT',
                filters: [
                    new CQLStandardFilterBuilderClass({
                        type: cqlAst.type,
                        filters: cqlAst.filters.map(function (filter) {
                            return uncollapseNOTs({ cqlAst: filter });
                        }),
                    }),
                ],
            });
        }
        else {
            return new CQLStandardFilterBuilderClass({
                type: cqlAst.type,
                filters: cqlAst.filters.map(function (filter) {
                    return uncollapseNOTs({ cqlAst: filter });
                }),
            });
        }
    }
    else {
        if (cqlAst.negated) {
            var clonedFieldFilter = _cloneDeep(cqlAst);
            return new CQLStandardFilterBuilderClass({
                type: 'NOT',
                filters: [
                    new CQLStandardFilterBuilderClass({
                        type: 'AND',
                        filters: [
                            new FilterClass(__assign({}, clonedFieldFilter)),
                        ],
                    }),
                ],
            });
        }
        else {
            return cqlAst;
        }
    }
}
function getDataTypesConfigurationUsingStartupStore() {
    return getDataTypesConfiguration({
        Configuration: StartupDataStore.Configuration,
        MetacardDefinitions: StartupDataStore.MetacardDefinitions,
    });
}
function handleAllFilterTypes(cqlAst) {
    var extraFilterClass = Extensions.extraFilters
        ? Extensions.extraFilters.filterTypesHandler(cqlAst)
        : null;
    if (isCQLStandardFilterBuilderClass(cqlAst) || isFilterBuilderClass(cqlAst)) {
        return new CQLStandardFilterBuilderClass({
            type: cqlAst.type,
            filters: cqlAst.filters.map(function (filter) { return handleAllFilterTypes(filter); }),
        });
    }
    else if (isBasicDatatypeClass(cqlAst)) {
        var dataTypeConfiguration_1 = getDataTypesConfigurationUsingStartupStore();
        var datatypeFilters_1 = [];
        cqlAst.value.map(function (value) {
            var relevantAttributes = dataTypeConfiguration_1.valueMap[value];
            if (relevantAttributes) {
                Object.keys(relevantAttributes.attributes).map(function (attribute) {
                    var relevantValues = relevantAttributes.attributes[attribute];
                    relevantValues.forEach(function (relevantValue) {
                        datatypeFilters_1.push(new FilterClass({
                            property: attribute,
                            value: relevantValue,
                            type: 'ILIKE',
                        }));
                    });
                });
            }
        });
        return new CQLStandardFilterBuilderClass({
            type: 'AND',
            filters: [
                new CQLStandardFilterBuilderClass({
                    type: 'OR',
                    filters: datatypeFilters_1,
                }),
            ],
        });
    }
    else if (extraFilterClass) {
        return extraFilterClass;
    }
    else if (isResourceSizeFilterClass(cqlAst)) {
        var bytesValue = convertResourceSizeFilterClassValueToBytes(cqlAst);
        return new FilterClass(__assign(__assign({}, cqlAst), { value: bytesValue }));
    }
    else if (isResourceSizeRangeFilterClass(cqlAst)) {
        var bytesValue = convertResourceSizeRangeFilterClassValueToBytes(cqlAst);
        return new FilterClass(__assign(__assign({}, cqlAst), { value: bytesValue }));
    }
    else {
        return cqlAst;
    }
}
/**
 * For now, all this does is remove anyDate from cql since that's purely for the UI to track the query basic view state correctly.
 * We might want to reconsider how we do the basic query in order to avoid this necessity (it's really the checkbox).
 *
 * This will only ever happen with a specific structure, so we don't need to recurse or anything.
 */
function removeInvalidFilters(cqlAst) {
    // loop over filters, splicing out invalid ones, at end of loop if all filters gone, remove self?
    if (isFilterBuilderClass(cqlAst) ||
        shouldBeFilterBuilderClass(cqlAst) ||
        isCQLStandardFilterBuilderClass(cqlAst)) {
        var i = cqlAst.filters.length;
        while (i--) {
            var currentFilter = cqlAst.filters[i];
            var validFilter = removeInvalidFilters(currentFilter);
            if (!validFilter) {
                cqlAst.filters.splice(i, 1);
            }
        }
        if (cqlAst.filters.length === 0) {
            return false;
        }
    }
    else {
        if (cqlAst.property === 'anyDate') {
            return false;
        }
        if (cqlAst.type === 'BOOLEAN_TEXT_SEARCH') {
            var booleanTextValue = cqlAst.value;
            if (booleanTextValue.error) {
                return false;
            }
        }
    }
    return cqlAst;
}
function iterativelySimplify(cqlAst) {
    var prevAst = _cloneDeep(cqlAst);
    simplifyAst(cqlAst);
    while (JSON.stringify(prevAst) !== JSON.stringify(cqlAst)) {
        prevAst = _cloneDeep(cqlAst);
        simplifyAst(cqlAst);
    }
    return cqlAst;
}
export default {
    /**
     * This function should be used only to test reconstitution, or as a last resort to handle upgrades from a system where the filter tree is
     * no longer compatible.  No loss of accuracy will occur, but nice UX touches like remembering coordinate systems and units will.
     *
     * Also, it may group things slightly different (we do our best effort, but the postfix notation technically causes parens around everything, and from there
     * we do a simplification, which means the resulting filter tree may look simpler than you remember).  However, once again, the accuracy and
     * results returned by the search will remain the same.
     * @param cql
     */
    read: function (cql) {
        if (cql === undefined || cql.length === 0) {
            return new FilterBuilderClass({
                type: 'AND',
                filters: [],
            });
        }
        // if anything goes wrong, simply log the error and move on (return a default filter tree).
        try {
            var reconstructedFilter = this.simplify(buildAst(tokenize(cql)));
            if (isFilterBuilderClass(reconstructedFilter) ||
                shouldBeFilterBuilderClass(reconstructedFilter)) {
                return new FilterBuilderClass(reconstructedFilter);
            }
            else {
                return new FilterBuilderClass({
                    type: 'AND',
                    filters: [reconstructedFilter],
                });
            }
        }
        catch (err) {
            console.error(err);
            return new FilterBuilderClass({ type: 'AND', filters: [] });
        }
    },
    write: function (filter) {
        try {
            var standardCqlAst = handleAllFilterTypes(uncollapseNOTs({
                cqlAst: filter,
            }));
            removeInvalidFilters(standardCqlAst);
            return write(standardCqlAst);
        }
        catch (err) {
            console.error(err);
            return write(new FilterBuilderClass({
                type: 'AND',
                filters: [],
            }));
        }
    },
    removeInvalidFilters: removeInvalidFilters,
    simplify: function (cqlAst) {
        return iterativelySimplify(cqlAst);
    },
    translateCqlToUserql: translateCqlToUserql,
    translateUserqlToCql: translateUserqlToCql,
    ANYTEXT_WILDCARD: ANYTEXT_WILDCARD,
    getGeoFilters: getGeoFilters,
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3FsLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc3JjL21haW4vd2ViYXBwL2pzL2NxbC50c3giXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBOzs7Ozs7Ozs7Ozs7O0lBYUk7QUFDSjs7OytCQUcrQjtBQUMvQixPQUFPLEVBRUwsNkJBQTZCLEVBQzdCLFdBQVcsRUFDWCxrQkFBa0IsRUFDbEIsV0FBVyxFQUNYLG9CQUFvQixFQUNwQixvQkFBb0IsRUFDcEIsK0JBQStCLEVBQy9CLFNBQVMsRUFDVCwwQkFBMEIsRUFFMUIsMENBQTBDLEVBQzFDLHlCQUF5QixFQUN6Qiw4QkFBOEIsRUFDOUIsK0NBQStDLEdBQ2hELE1BQU0sOENBQThDLENBQUE7QUFDckQsT0FBTyxFQUFFLHlCQUF5QixFQUFFLE1BQU0sOERBQThELENBQUE7QUFDeEcsT0FBTyxRQUFRLE1BQU0sWUFBWSxDQUFBO0FBQ2pDLE9BQU8sVUFBVSxNQUFNLGtCQUFrQixDQUFBO0FBQ3pDLE9BQU8sR0FBRyxNQUFNLEtBQUssQ0FBQTtBQUNyQixPQUFPLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSx5QkFBeUIsQ0FBQTtBQUMxRCxPQUFPLFVBQVUsTUFBTSxxQkFBcUIsQ0FBQTtBQUU1QyxJQUFNLG9CQUFvQixHQUFHLFVBQzNCLEtBQXVCLEVBQ3ZCLFFBQWdCLEVBQ2hCLE1BQWU7SUFFZixJQUFNLEtBQUssR0FBRztRQUNaLElBQUksRUFBRSxRQUFRO1FBQ2QsSUFBSSxFQUFFLGFBQWE7UUFDbkIsR0FBRyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUM7UUFDYixHQUFHLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQztLQUNkLENBQUE7SUFFRCxPQUFPLElBQUksV0FBVyxDQUFDO1FBQ3JCLElBQUksRUFBRSxVQUFVO1FBQ2hCLEtBQUssRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLHVCQUFNLEtBQUssS0FBRSxNQUFNLFFBQUEsSUFBRyxDQUFDLENBQUMsS0FBSyxDQUEyQjtRQUN4RSxRQUFRLFVBQUE7S0FDVCxDQUFDLENBQUE7QUFDSixDQUFDLENBQUE7QUFFRCxJQUFNLG1CQUFtQixHQUFHLFVBQzFCLElBQWdCLEVBQ2hCLFFBQWdCLEVBQ2hCLE1BQWU7SUFFZixJQUFNLEtBQUssR0FBRztRQUNaLElBQUksRUFBRSxNQUFNO1FBQ1osSUFBSSxFQUFFLE1BQU07UUFDWixJQUFJLEVBQUUsSUFBSTtLQUNYLENBQUE7SUFFRCxPQUFPLElBQUksV0FBVyxDQUFDO1FBQ3JCLElBQUksRUFBRSxVQUFVO1FBQ2hCLEtBQUssRUFBRSxDQUFDLE1BQU07WUFDWixDQUFDLHVCQUFNLEtBQUssS0FBRSxTQUFTLEVBQUUsTUFBTSxJQUMvQixDQUFDLENBQUMsS0FBSyxDQUEyQjtRQUNwQyxRQUFRLFVBQUE7S0FDVCxDQUFDLENBQUE7QUFDSixDQUFDLENBQUE7QUFFRCxJQUFNLGdCQUFnQixHQUFHLFVBQ3ZCLElBQWdCLEVBQ2hCLFFBQWdCLEVBQ2hCLE1BQWU7SUFFZixJQUFNLEtBQUssR0FBRztRQUNaLElBQUksRUFBRSxNQUFNO1FBQ1osSUFBSSxFQUFFLFNBQVM7UUFDZixPQUFPLEVBQUUsSUFBSTtLQUNkLENBQUE7SUFFRCxPQUFPLElBQUksV0FBVyxDQUFDO1FBQ3JCLElBQUksRUFBRSxVQUFVO1FBQ2hCLEtBQUssRUFBRSxDQUFDLE1BQU07WUFDWixDQUFDLHVCQUFNLEtBQUssS0FBRSxrQkFBa0IsRUFBRSxNQUFNLElBQ3hDLENBQUMsQ0FBQyxLQUFLLENBQTJCO1FBQ3BDLFFBQVEsVUFBQTtLQUNULENBQUMsQ0FBQTtBQUNKLENBQUMsQ0FBQTtBQUNELElBQU0sZ0JBQWdCLEdBQUcsdUJBQXVCLENBQUE7QUE0QmhELElBQU0sV0FBVyxHQUNiLHVJQUF1SSxFQUN6SSxRQUFRLEdBQUc7SUFDVCxzREFBc0Q7SUFDdEQsUUFBUSxFQUFFLGlDQUFpQztJQUMzQyxVQUFVLEVBQUUsK0JBQStCO0lBQzNDLE9BQU8sRUFBRSxXQUFXO0lBQ3BCLEtBQUssRUFBRSxJQUFJO0lBQ1gsT0FBTyxFQUFFLFlBQVk7SUFDckIsS0FBSyxFQUFFLHFDQUFxQztJQUM1QyxlQUFlLEVBQUUsYUFBYTtJQUM5QixPQUFPLEVBQUUsZ0JBQWdCO0lBQ3pCLE1BQU0sRUFBRSxLQUFLO0lBQ2IsTUFBTSxFQUFFLEtBQUs7SUFDYixPQUFPLEVBQUUsNkNBQTZDO0lBQ3RELEtBQUssRUFBRSxZQUFZO0lBQ25CLEdBQUcsRUFBRSxPQUFPO0lBQ1osT0FBTyxFQUFFLFdBQVc7SUFDcEIsTUFBTSxFQUFFLFVBQVU7SUFDbEIsS0FBSyxFQUFFLFNBQVM7SUFDaEIsTUFBTSxFQUFFLFVBQVU7SUFDbEIsUUFBUSxFQUFFLCtCQUErQjtJQUN6QyxJQUFJLEVBQUUsSUFBSSxNQUFNLENBQUMsR0FBRyxHQUFHLFdBQVcsQ0FBQyxNQUFNLENBQUM7SUFDMUMsV0FBVyxFQUFFLElBQUksTUFBTSxDQUNyQixHQUFHLEdBQUcsV0FBVyxDQUFDLE1BQU0sR0FBRyxHQUFHLEdBQUcsV0FBVyxDQUFDLE1BQU0sQ0FDcEQ7SUFDRCxRQUFRLFlBQUMsSUFBWTtRQUNuQixJQUFNLElBQUksR0FDUix3RkFBd0YsQ0FBQyxJQUFJLENBQzNGLElBQUksQ0FDTCxDQUFBO1FBQ0gsSUFBSSxJQUFJLEVBQUUsQ0FBQztZQUNULElBQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUE7WUFDdkIsSUFBSSxHQUFHLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFBO1lBQzNDLElBQUksR0FBRyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUM7Z0JBQ2IsSUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFBO2dCQUNiLE9BQU8sR0FBRyxHQUFHLEdBQUcsSUFBSSxLQUFLLEdBQUcsQ0FBQyxFQUFFLENBQUM7b0JBQzlCLEdBQUcsRUFBRSxDQUFBO29CQUNMLFFBQVEsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDO3dCQUN6QixLQUFLLEdBQUc7NEJBQ04sS0FBSyxFQUFFLENBQUE7NEJBQ1AsTUFBSzt3QkFDUCxLQUFLLEdBQUc7NEJBQ04sS0FBSyxFQUFFLENBQUE7NEJBQ1AsTUFBSzt3QkFDUCxRQUFRO3dCQUNSLDhCQUE4QjtvQkFDaEMsQ0FBQztnQkFDSCxDQUFDO1lBQ0gsQ0FBQztZQUNELE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQTtRQUNsQyxDQUFDO1FBQ0QsT0FBTyxJQUFJLENBQUE7SUFDYixDQUFDO0lBQ0QsR0FBRyxFQUFFLElBQUk7Q0FDNkMsRUFDeEQsT0FBTyxHQUFHO0lBQ1IsU0FBUyxFQUFFO1FBQ1QsS0FBSztRQUNMLFVBQVU7UUFDVixTQUFTO1FBQ1QsaUJBQWlCO1FBQ2pCLFVBQVU7UUFDVixRQUFRO0tBQ1Q7SUFDRCxNQUFNLEVBQUU7UUFDTixLQUFLO1FBQ0wsVUFBVTtRQUNWLFNBQVM7UUFDVCxpQkFBaUI7UUFDakIsVUFBVTtRQUNWLE9BQU87UUFDUCxRQUFRO0tBQ1Q7SUFDRCxNQUFNLEVBQUUsQ0FBQyxLQUFLLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsWUFBWSxFQUFFLE9BQU8sQ0FBQztJQUNsRSxRQUFRLEVBQUU7UUFDUixZQUFZO1FBQ1osU0FBUztRQUNULE9BQU87UUFDUCxTQUFTO1FBQ1QsUUFBUTtRQUNSLE9BQU87UUFDUCxRQUFRO1FBQ1IsUUFBUTtLQUNUO0lBQ0QsT0FBTyxFQUFFLENBQUMsT0FBTyxDQUFDO0lBQ2xCLE9BQU8sRUFBRSxDQUFDLFFBQVEsRUFBRSxTQUFTLEVBQUUsR0FBRyxFQUFFLEdBQUcsQ0FBQztJQUN4QyxVQUFVLEVBQUUsQ0FBQyxVQUFVLEVBQUUsT0FBTyxFQUFFLFNBQVMsQ0FBQztJQUM1QyxLQUFLLEVBQUUsQ0FBQyxpQkFBaUIsRUFBRSxVQUFVLEVBQUUsT0FBTyxFQUFFLE9BQU8sRUFBRSxVQUFVLENBQUM7SUFDcEUsS0FBSyxFQUFFLENBQUMsU0FBUyxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsS0FBSyxDQUFDO0lBQzVDLE9BQU8sRUFBRSxDQUFDLFFBQVEsQ0FBQztJQUNuQixPQUFPLEVBQUUsQ0FBQyxRQUFRLENBQUM7SUFDbkIsS0FBSyxFQUFFLENBQUMsUUFBUSxDQUFDO0lBQ2pCLE9BQU8sRUFBRTtRQUNQLGlCQUFpQjtRQUNqQixLQUFLO1FBQ0wsT0FBTztRQUNQLFNBQVM7UUFDVCxVQUFVO1FBQ1YsUUFBUTtLQUNUO0lBQ0QsR0FBRyxFQUFFLENBQUMsVUFBVSxFQUFFLFFBQVEsQ0FBQztJQUMzQixRQUFRLEVBQUUsQ0FBQyxPQUFPLEVBQUUsUUFBUSxDQUFDO0lBQzdCLE1BQU0sRUFBRSxDQUFDLE1BQU0sQ0FBQztJQUNoQixLQUFLLEVBQUUsQ0FBQyxNQUFNLENBQUM7SUFDZixNQUFNLEVBQUUsQ0FBQyxhQUFhLENBQUM7SUFDdkIsSUFBSSxFQUFFLENBQUMsU0FBUyxFQUFFLFFBQVEsRUFBRSxLQUFLLENBQUM7SUFDbEMsV0FBVyxFQUFFLENBQUMsU0FBUyxFQUFFLFFBQVEsRUFBRSxLQUFLLENBQUM7SUFDekMsUUFBUSxFQUFFLENBQUMsUUFBUSxFQUFFLEtBQUssQ0FBQztJQUMzQixlQUFlLEVBQUUsQ0FBQyxRQUFRLEVBQUUsVUFBVSxFQUFFLE9BQU8sRUFBRSxRQUFRLENBQUM7SUFDMUQsR0FBRyxFQUFFLEVBQUU7Q0FJUixFQUNELFVBQVUsR0FBRztJQUNYLE1BQU0sRUFBRSxDQUFDO0lBQ1QsT0FBTyxFQUFFLENBQUM7SUFDVixVQUFVLEVBQUUsQ0FBQztDQUNxQjtBQUNwQywrRUFBK0U7QUFDL0Usd0JBQXdCLEdBQUc7SUFDekIsU0FBUyxFQUFFLENBQUM7SUFDWixFQUFFLEVBQUUsQ0FBQztDQUNpQyxFQUN4QyxjQUFjLEdBQUcsOEJBQThCLENBQUE7QUFFakQsU0FBUyxRQUFRLENBQUMsSUFBWSxFQUFFLE9BQTBCO0lBQ3hELElBQUksT0FBTyxZQUFZLE1BQU0sRUFBRSxDQUFDO1FBQzlCLE9BQU8sT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQTtJQUMzQixDQUFDO1NBQU0sQ0FBQztRQUNOLE9BQU8sT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFBO0lBQ3RCLENBQUM7QUFDSCxDQUFDO0FBRUQsU0FBUyxTQUFTLENBQUMsSUFBWSxFQUFFLE1BQXVDO0lBQ3RFLElBQUksQ0FBQyxFQUNILEtBQUssRUFDTCxHQUFHLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQTtJQUNyQixLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEdBQUcsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDO1FBQ3pCLEtBQUssR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUE7UUFDakIsSUFBTSxHQUFHLEdBQUcsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFBO1FBQzNCLElBQU0sT0FBTyxHQUFHLFFBQVEsQ0FBQyxJQUFJLEVBQUUsR0FBRyxDQUFDLENBQUE7UUFDbkMsSUFBSSxPQUFPLEVBQUUsQ0FBQztZQUNaLElBQU0sS0FBSyxHQUFHLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQTtZQUN4QixJQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxDQUFBO1lBQy9ELE9BQU87Z0JBQ0wsSUFBSSxFQUFFLEtBQUs7Z0JBQ1gsSUFBSSxFQUFFLEtBQUs7Z0JBQ1gsU0FBUyxXQUFBO2FBQ1YsQ0FBQTtRQUNILENBQUM7SUFDSCxDQUFDO0lBRUQsSUFBSSxHQUFHLEdBQUcsc0JBQXNCLEdBQUcsSUFBSSxHQUFHLHNCQUFzQixDQUFBO0lBQ2hFLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsR0FBRyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUM7UUFDekIsS0FBSyxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQTtRQUNqQixHQUFHLElBQUksUUFBUSxHQUFHLEtBQUssR0FBRyxJQUFJLEdBQUcsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFBO0lBQ2xELENBQUM7SUFFRCxNQUFNLElBQUksS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFBO0FBQ3RCLENBQUM7QUFRRCxTQUFTLFFBQVEsQ0FBQyxJQUFZO0lBQzVCLElBQU0sT0FBTyxHQUFHLEVBQUUsQ0FBQTtJQUNsQixJQUFJLEtBQUssR0FBRyxTQUFrQyxDQUFBO0lBQzlDLElBQUksTUFBTSxHQUFHLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQTtJQUVqQyxHQUFHLENBQUM7UUFDRixLQUFLLEdBQUcsU0FBUyxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsQ0FBQTtRQUMvQixJQUFJLEdBQUcsS0FBSyxDQUFDLFNBQVMsQ0FBQTtRQUN0QixNQUFNLEdBQUcsT0FBTyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQTtRQUM1QixJQUFJLEtBQUssQ0FBQyxJQUFJLEtBQUssS0FBSyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDcEMsTUFBTSxJQUFJLEtBQUssQ0FBQyxzQkFBc0IsR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUE7UUFDdEQsQ0FBQztRQUNELE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUE7SUFDckIsQ0FBQyxRQUFRLEtBQUssQ0FBQyxJQUFJLEtBQUssS0FBSyxFQUFDO0lBQzlCLE9BQU8sT0FBTyxDQUFBO0FBQ2hCLENBQUM7QUFJRCw0REFBNEQ7QUFDNUQsSUFBTSxXQUFXLEdBQUc7SUFDbEIsR0FBRyxFQUFFLEdBQUc7SUFDUixHQUFHLEVBQUUsR0FBRztJQUNSLEdBQUcsRUFBRSxLQUFLO0lBQ1YsQ0FBQyxFQUFFLEtBQUs7Q0FDVCxDQUFBO0FBRUQsSUFBTSxvQkFBb0IsR0FBRyxVQUFDLEdBQVc7SUFDdkMsT0FBQSxHQUFHLENBQUMsT0FBTyxDQUNULHFCQUFxQixFQUNyQixVQUFDLENBQUMsRUFBRSxDQUFNLEVBQUUsQ0FBQztRQUFULGtCQUFBLEVBQUEsTUFBTTtRQUNSLE9BQUEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBeUIsQ0FBQyxDQUFDO0lBQTdELENBQTZELENBQ2hFO0FBSkQsQ0FJQyxDQUFBO0FBRUgsMkRBQTJEO0FBQzNELElBQU0sV0FBVyxHQUFHO0lBQ2xCLEdBQUcsRUFBRSxHQUFHO0lBQ1IsQ0FBQyxFQUFFLEdBQUc7Q0FDaUMsQ0FBQTtBQUV6QyxJQUFNLG9CQUFvQixHQUFHLFVBQUMsR0FBVztJQUN2QyxPQUFBLEdBQUcsQ0FBQyxPQUFPLENBQUMsaUJBQWlCLEVBQUUsVUFBQyxDQUFDLEVBQUUsQ0FBTSxFQUFFLENBQUM7UUFBVCxrQkFBQSxFQUFBLE1BQU07UUFDdkMsT0FBQSxDQUFDLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxXQUFXLENBQUMsQ0FBeUIsQ0FBQztJQUEzRCxDQUEyRCxDQUM1RDtBQUZELENBRUMsQ0FBQTtBQUVILElBQU0sWUFBWSxHQUFHLFVBQUMsT0FBeUI7SUFDN0MsSUFDRSxPQUFPLENBQUMsT0FBTyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7UUFDM0IsT0FBTyxDQUFDLE9BQU8sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxLQUFLLGlCQUFpQixFQUN0RCxDQUFDO1FBQ0Qsd0JBQXdCO1FBQ3hCLE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQTtRQUNiLE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQTtRQUNiLE9BQU8sT0FBTyxDQUFDLEdBQUcsRUFBZSxDQUFBO0lBQ25DLENBQUM7SUFDRCxJQUNFLE9BQU8sQ0FBQyxPQUFPLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztRQUMzQixPQUFPLENBQUMsT0FBTyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLEtBQUssVUFBVSxFQUMvQyxDQUFDO1FBQ0QsdUJBQXVCO1FBQ3ZCLE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQTtRQUNiLE9BQU8sT0FBTyxDQUFDLEdBQUcsRUFBZSxDQUFBO0lBQ25DLENBQUM7SUFDRCxPQUFPLE9BQU8sQ0FBQyxHQUFHLEVBQWUsQ0FBQTtBQUNuQyxDQUFDLENBQUE7QUFFRCxJQUFNLGFBQWEsR0FBRyxVQUNwQixHQUFXLEVBQ1gsUUFBZ0IsRUFDaEIsTUFBZTtJQUVmLElBQUksR0FBRyxDQUFDLFVBQVUsQ0FBQyxvQkFBb0IsQ0FBQyxFQUFFLENBQUM7UUFDekMsSUFBTSxTQUFTLEdBQUcsR0FBRyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUE7UUFDekMsSUFBTSxPQUFPLEdBQUcsU0FBUyxDQUFDLFNBQVMsRUFBUyxDQUFBO1FBQzVDLElBQU0sU0FBUyxHQUFhLE9BQU8sQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLFVBQUMsUUFBYTtZQUMvRCxPQUFBLEdBQUcsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEtBQUssRUFBRTtRQUEzQyxDQUEyQyxDQUM1QyxDQUFBO1FBQ0QsT0FBTyxJQUFJLGtCQUFrQixDQUFDO1lBQzVCLElBQUksRUFBRSxJQUFJO1lBQ1YsT0FBTyxFQUFFLFNBQVMsQ0FBQyxHQUFHLENBQUMsVUFBQyxHQUFHLElBQUssT0FBQSxhQUFhLENBQUMsR0FBRyxFQUFFLFFBQVEsRUFBRSxNQUFNLENBQUMsRUFBcEMsQ0FBb0MsQ0FBQztTQUN0RSxDQUFDLENBQUE7SUFDSixDQUFDO1NBQU0sSUFBSSxHQUFHLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUM7UUFDeEMsSUFBTSxJQUFJLEdBQUcsUUFBUSxDQUFDLHNCQUFzQixDQUFDLEdBQUcsQ0FBQyxDQUFBO1FBQ2pELE9BQU8sbUJBQW1CLENBQUMsSUFBSSxFQUFFLFFBQVEsRUFBRSxNQUFNLENBQUMsQ0FBQTtJQUNwRCxDQUFDO1NBQU0sSUFBSSxHQUFHLENBQUMsVUFBVSxDQUFDLGlCQUFpQixDQUFDLEVBQUUsQ0FBQztRQUM3QyxPQUFPLElBQUksa0JBQWtCLENBQUM7WUFDNUIsSUFBSSxFQUFFLElBQUk7WUFDVixPQUFPLEVBQUUsUUFBUSxDQUFDLDJCQUEyQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FDcEQsVUFBQyxJQUFnQixJQUFLLE9BQUEsbUJBQW1CLENBQUMsSUFBSSxFQUFFLFFBQVEsRUFBRSxNQUFNLENBQUMsRUFBM0MsQ0FBMkMsQ0FDbEU7U0FDRixDQUFDLENBQUE7SUFDSixDQUFDO1NBQU0sSUFBSSxHQUFHLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUM7UUFDckMsSUFBTSxJQUFJLEdBQUcsUUFBUSxDQUFDLG1CQUFtQixDQUFDLEdBQUcsQ0FBQyxDQUFBO1FBQzlDLE9BQU8sZ0JBQWdCLENBQUMsSUFBSSxFQUFFLFFBQVEsRUFBRSxNQUFNLENBQUMsQ0FBQTtJQUNqRCxDQUFDO1NBQU0sSUFBSSxHQUFHLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxFQUFFLENBQUM7UUFDMUMsT0FBTyxJQUFJLGtCQUFrQixDQUFDO1lBQzVCLElBQUksRUFBRSxJQUFJO1lBQ1YsT0FBTyxFQUFFLFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsVUFBQyxJQUFnQjtnQkFDOUQsT0FBQSxnQkFBZ0IsQ0FBQyxJQUFJLEVBQUUsUUFBUSxFQUFFLE1BQU0sQ0FBQztZQUF4QyxDQUF3QyxDQUN6QztTQUNGLENBQUMsQ0FBQTtJQUNKLENBQUM7U0FBTSxJQUFJLEdBQUcsQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQztRQUNuQyxJQUFNLEtBQUssR0FBRyxRQUFRLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUE7UUFDaEQsT0FBTyxvQkFBb0IsQ0FBQyxLQUFLLEVBQUUsUUFBUSxFQUFFLE1BQU0sQ0FBQyxDQUFBO0lBQ3RELENBQUM7U0FBTSxJQUFJLEdBQUcsQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQztRQUN4QyxPQUFPLElBQUksa0JBQWtCLENBQUM7WUFDNUIsSUFBSSxFQUFFLElBQUk7WUFDVixPQUFPLEVBQUUsUUFBUSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxVQUFDLEtBQXVCO2dCQUNuRSxPQUFBLG9CQUFvQixDQUFDLEtBQUssRUFBRSxRQUFRLEVBQUUsTUFBTSxDQUFDO1lBQTdDLENBQTZDLENBQzlDO1NBQ0YsQ0FBQyxDQUFBO0lBQ0osQ0FBQztJQUNELE1BQU0sSUFBSSxLQUFLLENBQUMsa0NBQWtDLENBQUMsQ0FBQTtBQUNyRCxDQUFDLENBQUE7QUFFRCxTQUFTLFNBQVMsQ0FBQyxPQUF5QjtJQUMxQyxJQUFJLEtBQUssRUFDUCxRQUFRLEVBQ1IsR0FBRyxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQTtJQUM3QixJQUFNLFNBQVMsR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFBO0lBQzFCLFFBQVEsU0FBUyxFQUFFLENBQUM7UUFDbEIsS0FBSyxTQUFTO1lBQ1osSUFBTSxHQUFHLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FBQyxFQUM1QixHQUFHLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFBO1lBQzFCLE9BQU8sSUFBSSxrQkFBa0IsQ0FBQztnQkFDNUIsT0FBTyxFQUFFLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQztnQkFDbkIsSUFBSSxFQUFFLEdBQUcsQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFnQzthQUMzRCxDQUFDLENBQUE7UUFDSixLQUFLLEtBQUs7WUFDUixJQUFNLFNBQVMsR0FBRyxPQUFPLENBQUMsT0FBTyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQWMsQ0FBQTtZQUMxRCxJQUFJLFNBQVMsQ0FBQyxJQUFJLEtBQUssU0FBUyxFQUFFLENBQUM7Z0JBQ2pDLE9BQU8sSUFBSSxrQkFBa0IsdUJBQ3hCLFNBQVMsQ0FBQyxPQUFPLENBQUMsS0FDckIsT0FBTyxFQUFFLElBQUksSUFDYixDQUFBO1lBQ0osQ0FBQztpQkFBTSxJQUFJLFNBQVMsQ0FBQyxJQUFJLEtBQUssS0FBSyxFQUFFLENBQUM7Z0JBQ3BDLE9BQU8sSUFBSSxrQkFBa0IsQ0FBQztvQkFDNUIsT0FBTyxFQUFFLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDO29CQUM3QixJQUFJLEVBQUUsS0FBSztvQkFDWCxPQUFPLEVBQUUsSUFBSTtpQkFDZCxDQUFDLENBQUE7WUFDSixDQUFDO2lCQUFNLENBQUM7Z0JBQ04sT0FBTyxJQUFJLFdBQVcsdUJBQ2pCLFNBQVMsQ0FBQyxPQUFPLENBQUMsS0FDckIsT0FBTyxFQUFFLElBQUksSUFDYixDQUFBO1lBQ0osQ0FBQztRQUNILEtBQUssU0FBUyxFQUFFLFFBQVE7WUFDdEIsSUFBSSxHQUFHLFNBQUEsRUFBRSxHQUFHLFNBQUEsQ0FBQTtZQUNaLE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQSxDQUFDLDBCQUEwQjtZQUN4QyxHQUFHLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFBO1lBQ3hCLEdBQUcsR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUE7WUFDeEIsUUFBUSxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQTtZQUM3QixPQUFPLElBQUksV0FBVyxDQUFDO2dCQUNyQixRQUFRLFVBQUE7Z0JBQ1IsS0FBSyxFQUFFO29CQUNMLEtBQUssRUFBRSxHQUFHO29CQUNWLEdBQUcsRUFBRSxHQUFHO2lCQUNnQjtnQkFDMUIsSUFBSSxFQUFFLFNBQWdDO2FBQ3ZDLENBQUMsQ0FBQTtRQUNKLEtBQUssUUFBUSxDQUFDLENBQUMsUUFBUTtRQUN2QixLQUFLLE9BQU8sRUFBRSxRQUFRO1lBQ3BCLEtBQUssR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUE7WUFDMUIsUUFBUSxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQTtZQUM3QixPQUFPLElBQUksV0FBVyxDQUFDO2dCQUNyQixRQUFRLFVBQUE7Z0JBQ1IsS0FBSyxFQUFFLEtBQTJCO2dCQUNsQyxJQUFJLEVBQUUsR0FBRyxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQXlCO2FBQ3BELENBQUMsQ0FBQTtRQUNKLEtBQUssUUFBUSxFQUFFLHVDQUF1QztZQUNwRCxJQUFNLEtBQUssR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFBO1lBQzNDLFFBQVEsR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUE7WUFDN0IsT0FBTyxJQUFJLFdBQVcsQ0FBQztnQkFDckIsUUFBUSxVQUFBO2dCQUNSLEtBQUssRUFBRTtvQkFDTCxLQUFLLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQztvQkFDZixHQUFHLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQztpQkFDVTtnQkFDekIsSUFBSSxFQUFFLEdBQUcsQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUF5QjthQUNwRCxDQUFDLENBQUE7UUFDSixLQUFLLFlBQVksRUFBRSxRQUFRO1lBQ3pCLEtBQUssR0FBRyxTQUFTLENBQUMsT0FBTyxDQUEwQixDQUFBO1lBQ25ELFFBQVEsR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUE7WUFDN0IsT0FBTyxJQUFJLFdBQVcsQ0FBQztnQkFDckIsUUFBUSxVQUFBO2dCQUNSLEtBQUssT0FBQTtnQkFDTCxJQUFJLEVBQUUsR0FBRyxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQXlCO2FBQ3BELENBQUMsQ0FBQTtRQUNKLEtBQUssU0FBUyxFQUFFLFFBQVE7WUFDdEIsUUFBUSxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQTtZQUM3QixPQUFPLElBQUksV0FBVyxDQUFDO2dCQUNyQixRQUFRLFVBQUE7Z0JBQ1IsSUFBSSxFQUFFLEdBQUcsQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUF5QjthQUNwRCxDQUFDLENBQUE7UUFDSixLQUFLLE9BQU8sRUFBRSxPQUFPO1lBQ25CLElBQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFBO1lBQ3hDLElBQUksS0FBSyxFQUFFLENBQUM7Z0JBQ1YsSUFBSSxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLElBQUksRUFBRSxDQUFDO29CQUNyQyxtQkFBbUI7b0JBQ25CLE9BQU8sS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsR0FBRyxDQUFDLENBQUE7Z0JBQ3JDLENBQUM7cUJBQU0sQ0FBQztvQkFDTixPQUFPLG9CQUFvQixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUE7Z0JBQzNELENBQUM7WUFDSCxDQUFDO2lCQUFNLENBQUM7Z0JBQ04sT0FBTyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFBO1lBQ3pCLENBQUM7UUFDSCxLQUFLLFNBQVMsRUFBRSxRQUFRO1lBQ3RCLFFBQVEsR0FBRyxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsRUFBRSxDQUFDO2dCQUMvQixLQUFLLE1BQU07b0JBQ1QsT0FBTyxJQUFJLENBQUE7Z0JBQ2I7b0JBQ0UsT0FBTyxLQUFLLENBQUE7WUFDaEIsQ0FBQztRQUNILEtBQUssU0FBUyxFQUFFLFVBQVU7WUFDeEIsNERBQTREO1lBQzVELFFBQVEsR0FBRyxDQUFDLElBQUksRUFBRSxDQUFDO2dCQUNqQixLQUFLLFlBQVksQ0FBQyxDQUFDLENBQUM7b0JBQ2xCLGdEQUFnRDtvQkFDaEQsSUFBTSxVQUFVLEdBQUcsT0FBTyxDQUFDLEdBQUcsRUFBZSxDQUFBO29CQUM3QyxJQUFNLGFBQWEsR0FBRyxPQUFPLENBQUMsR0FBRyxFQUFlLENBQUE7b0JBQ2hELE9BQU8sYUFBYSxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsYUFBYSxDQUFDLElBQUksRUFBRSxTQUFTLENBQUMsQ0FBQTtnQkFDdEUsQ0FBQztnQkFDRCxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUM7b0JBQ2Ysb0RBQW9EO29CQUNwRCxJQUFNLFdBQVcsR0FBRyxPQUFPLENBQUMsR0FBRyxFQUFlLENBQUE7b0JBQzlDLElBQU0sVUFBVSxHQUFHLE9BQU8sQ0FBQyxHQUFHLEVBQWUsQ0FBQTtvQkFDN0MsSUFBTSxhQUFhLEdBQUcsT0FBTyxDQUFDLEdBQUcsRUFBZSxDQUFBO29CQUNoRCxPQUFPLGFBQWEsQ0FDbEIsVUFBVSxDQUFDLElBQUksRUFDZixhQUFhLENBQUMsSUFBSSxFQUNsQixXQUFXLENBQUMsSUFBSSxDQUNqQixDQUFBO2dCQUNILENBQUM7Z0JBQ0Q7b0JBQ0UsTUFBTSxJQUFJLEtBQUssQ0FBQyxrQ0FBa0MsQ0FBQyxDQUFBO1lBQ3ZELENBQUM7UUFDSCxLQUFLLFVBQVU7WUFDYixPQUFPO2dCQUNMLElBQUksRUFBRSxTQUFTO2dCQUNmLEtBQUssRUFBRSxHQUFHLENBQUMsSUFBSTthQUNoQixDQUFBO1FBQ0gsS0FBSyxVQUFVO1lBQ2IsT0FBTyxJQUFJLFdBQVcsQ0FBQztnQkFDckIsSUFBSSxFQUFFLFVBQVU7Z0JBQ2hCLEtBQUssRUFBRSxXQUFXLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUM7Z0JBQ3pDLFFBQVEsRUFBRyxPQUFPLENBQUMsR0FBRyxFQUFnQixDQUFDLElBQUk7YUFDNUMsQ0FBQyxDQUFBO1FBQ0osS0FBSyxpQkFBaUIsRUFBRSxVQUFVO1lBQ2hDLElBQU0sa0JBQWtCLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUEsQ0FBQyxzQkFBc0I7WUFDdkUsSUFBTSxVQUFVLEdBQ2Qsd0JBQXdCLENBQUMsa0JBQXlDLENBQUMsQ0FBQTtZQUNyRSxJQUFJLFVBQVUsS0FBSyxTQUFTLEVBQUUsQ0FBQztnQkFDN0IsTUFBTSxJQUFJLEtBQUssQ0FBQywrQkFBK0IsR0FBRyxrQkFBa0IsQ0FBQyxDQUFBO1lBQ3ZFLENBQUM7WUFDRCxJQUFNLE1BQU0sR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUM7aUJBQ2hELEdBQUcsQ0FBQyxjQUFNLE9BQUEsU0FBUyxDQUFDLE9BQU8sQ0FBQyxFQUFsQixDQUFrQixDQUFDO2lCQUM3QixPQUFPLEVBQUUsQ0FBQTtZQUNaLFFBQVEsa0JBQWtCLEVBQUUsQ0FBQztnQkFDM0IsS0FBSyxXQUFXO29CQUNkLElBQU0sZ0JBQWdCLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBVyxDQUFBO29CQUM1QyxPQUFPLElBQUksV0FBVyxDQUFDO3dCQUNyQixJQUFJLEVBQUUsMkJBQTJCO3dCQUNqQyxRQUFRLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQzt3QkFDbkIsS0FBSyxFQUFFOzRCQUNMLEtBQUssRUFBRSxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDOzRCQUNyQyxNQUFNLEVBQUUsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQzs0QkFDdEMsUUFBUSxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUM7eUJBQ087cUJBQzdCLENBQUMsQ0FBQTtnQkFDSjtvQkFDRSxNQUFNLElBQUksS0FBSyxDQUFDLHlCQUF5QixDQUFDLENBQUE7WUFDOUMsQ0FBQztRQUNILEtBQUssYUFBYTtZQUNoQixPQUFPLEdBQUcsQ0FBQyxJQUFJLENBQUE7UUFDakI7WUFDRSxPQUFPLEdBQUcsQ0FBQyxJQUFJLENBQUE7SUFDbkIsQ0FBQztBQUNILENBQUM7QUFFRCxTQUFTLFFBQVEsQ0FBQyxNQUFtQjtJQUNuQyxJQUFNLGFBQWEsR0FBRyxFQUFzQixFQUMxQyxPQUFPLEdBQUcsRUFBc0IsQ0FBQTtJQUVsQyxPQUFPLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUNyQixJQUFNLEdBQUcsR0FBRyxNQUFNLENBQUMsS0FBSyxFQUFlLENBQUE7UUFDdkMsUUFBUSxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUM7WUFDakIsS0FBSyxVQUFVO2dCQUNiLEdBQUcsQ0FBQyxJQUFJLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQTtZQUM3QixLQUFLLFVBQVUsQ0FBQztZQUNoQixLQUFLLE9BQU8sQ0FBQztZQUNiLEtBQUssTUFBTSxDQUFDO1lBQ1osS0FBSyxhQUFhLENBQUM7WUFDbkIsS0FBSyxVQUFVLENBQUM7WUFDaEIsS0FBSyxTQUFTO2dCQUNaLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUE7Z0JBQ2pCLE1BQUs7WUFDUCxLQUFLLFlBQVksQ0FBQztZQUNsQixLQUFLLFNBQVMsQ0FBQztZQUNmLEtBQUssU0FBUyxDQUFDO1lBQ2YsS0FBSyxTQUFTLENBQUM7WUFDZixLQUFLLFFBQVEsQ0FBQztZQUNkLEtBQUssT0FBTyxDQUFDO1lBQ2IsS0FBSyxRQUFRO2dCQUNYLElBQU0sQ0FBQyxHQUFHLFVBQVUsQ0FBQyxHQUFHLENBQUMsSUFBdUIsQ0FBQyxDQUFBO2dCQUVqRCxPQUNFLGFBQWEsQ0FBQyxNQUFNLEdBQUcsQ0FBQztvQkFDeEIsVUFBVSxDQUNSLGFBQWEsQ0FBQyxhQUFhLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQXVCLENBQ2hFLElBQUksQ0FBQyxFQUNOLENBQUM7b0JBQ0QsT0FBTyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxFQUFlLENBQUMsQ0FBQTtnQkFDaEQsQ0FBQztnQkFFRCxhQUFhLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFBO2dCQUN2QixNQUFLO1lBQ1AsS0FBSyxTQUFTLENBQUM7WUFDZixLQUFLLEtBQUssQ0FBQztZQUNYLEtBQUssUUFBUTtnQkFDWCxhQUFhLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFBO2dCQUN2QixNQUFLO1lBQ1AsS0FBSyxpQkFBaUI7Z0JBQ3BCLGFBQWEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUE7Z0JBQ3ZCLCtGQUErRjtnQkFDL0YsYUFBYSxDQUFDLElBQUksQ0FBQyxFQUFFLElBQUksRUFBRSxRQUFRLEVBQWUsQ0FBQyxDQUFBO2dCQUNuRCxNQUFLO1lBQ1AsS0FBSyxRQUFRO2dCQUNYLE9BQ0UsYUFBYSxDQUFDLE1BQU0sR0FBRyxDQUFDO29CQUN4QixhQUFhLENBQUMsYUFBYSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLEtBQUssUUFBUSxFQUN6RCxDQUFDO29CQUNELE9BQU8sQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLEdBQUcsRUFBZSxDQUFDLENBQUE7Z0JBQ2hELENBQUM7Z0JBQ0QsYUFBYSxDQUFDLEdBQUcsRUFBRSxDQUFBLENBQUMsc0JBQXNCO2dCQUUxQyw2RkFBNkY7Z0JBQzdGLGlFQUFpRTtnQkFDakUsSUFBTSxnQkFBZ0IsR0FDcEIsYUFBYSxDQUFDLE1BQU0sR0FBRyxDQUFDO29CQUN4QixhQUFhLENBQUMsYUFBYSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUE7Z0JBQzlDLElBQ0UsZ0JBQWdCLEtBQUssU0FBUztvQkFDOUIsZ0JBQWdCLEtBQUssaUJBQWlCLEVBQ3RDLENBQUM7b0JBQ0QsT0FBTyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxFQUFlLENBQUMsQ0FBQTtnQkFDaEQsQ0FBQztnQkFDRCxNQUFLO1lBQ1AsS0FBSyxPQUFPLENBQUM7WUFDYixLQUFLLEtBQUssQ0FBQztZQUNYLEtBQUssT0FBTztnQkFDVixNQUFLO1lBQ1A7Z0JBQ0UsTUFBTSxJQUFJLEtBQUssQ0FBQyxxQkFBcUIsR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUE7UUFDckQsQ0FBQztJQUNILENBQUM7SUFFRCxPQUFPLGFBQWEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7UUFDaEMsT0FBTyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxFQUFlLENBQUMsQ0FBQTtJQUNoRCxDQUFDO0lBRUQsSUFBTSxNQUFNLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFBO0lBQ2pDLElBQUksT0FBTyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQztRQUN2QixJQUFJLEdBQUcsR0FBRyx5Q0FBeUMsQ0FBQTtRQUNuRCxLQUFLLElBQUksQ0FBQyxHQUFHLE9BQU8sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQztZQUM3QyxHQUFHLElBQUksT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksR0FBRyxJQUFJLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksR0FBRyxJQUFJLENBQUE7UUFDeEQsQ0FBQztRQUNELE1BQU0sSUFBSSxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUE7SUFDdEIsQ0FBQztJQUVELE9BQU8sTUFBTSxDQUFBO0FBQ2YsQ0FBQztBQUVELFNBQVMsSUFBSSxDQUFDLFFBQWdCO0lBQzVCLElBQUksT0FBTyxHQUFHLFFBQVEsQ0FBQTtJQUN0QixJQUFJLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDO1FBQzdCLE9BQU8sR0FBRyxHQUFHLEdBQUcsT0FBTyxDQUFBO0lBQ3pCLENBQUM7SUFDRCxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDO1FBQzNCLE9BQU8sR0FBRyxPQUFPLEdBQUcsR0FBRyxDQUFBO0lBQ3pCLENBQUM7SUFDRCxPQUFPLE9BQU8sQ0FBQTtBQUNoQixDQUFDO0FBRUQsU0FBUyxNQUFNLENBQUMsUUFBZ0I7SUFDOUIsaUVBQWlFO0lBQ2pFLE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsQ0FBQTtBQUM3RCxDQUFDO0FBRUQsbUpBQW1KO0FBQ25KLFNBQVMsS0FBSyxDQUFDLE1BQVc7SUFDeEIsUUFBUSxNQUFNLENBQUMsSUFBSSxFQUFFLENBQUM7UUFDcEIsZUFBZTtRQUNmLEtBQUssTUFBTTtZQUNULElBQU0sSUFBSSxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQzFCLElBQUksR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUN0QixJQUFJLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFDdEIsSUFBSSxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUE7WUFDeEIsT0FBTyxDQUNMLE9BQU87Z0JBQ1AsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUM7Z0JBQ3JCLEdBQUc7Z0JBQ0gsSUFBSTtnQkFDSixHQUFHO2dCQUNILElBQUk7Z0JBQ0osR0FBRztnQkFDSCxJQUFJO2dCQUNKLEdBQUc7Z0JBQ0gsSUFBSTtnQkFDSixHQUFHLENBQ0osQ0FBQTtRQUNILHVDQUF1QztRQUN2QyxLQUFLLFNBQVM7WUFDWixPQUFPLGtCQUFXLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLGVBQUssTUFBTSxDQUFDLEtBQUssZUFDdEQsTUFBTSxDQUFDLFFBQVEsY0FDTixDQUFBO1FBQ2IsdUJBQXVCO1FBQ3ZCLEtBQUssUUFBUTtZQUNYLE9BQU8sQ0FDTCxTQUFTLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsR0FBRyxJQUFJLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsR0FBRyxHQUFHLENBQ3JFLENBQUE7UUFDSCxnQkFBZ0I7UUFDaEIsS0FBSyxZQUFZO1lBQ2YsT0FBTyxhQUFhLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsR0FBRyxJQUFJLEdBQUcsTUFBTSxDQUFDLEtBQUssR0FBRyxHQUFHLENBQUE7UUFDMUUsdUJBQXVCO1FBQ3ZCLEtBQUssVUFBVTtZQUNiLE9BQU8sQ0FDTCxXQUFXLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsR0FBRyxJQUFJLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsR0FBRyxHQUFHLENBQ3ZFLENBQUE7UUFDSCxvR0FBb0c7UUFDcEcsOEZBQThGO1FBQzlGLDhFQUE4RTtRQUM5RSxLQUFLLFVBQVU7WUFDYixPQUFPLEtBQUssQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEVBQUUsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUE7UUFDakUsZUFBZTtRQUNmLEtBQUssS0FBSyxDQUFDO1FBQ1gsS0FBSyxJQUFJO1lBQ1AsSUFBSSxHQUFHLEdBQUcsR0FBRyxDQUFBO1lBQ2IsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFBO1lBQ2hCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDO2dCQUMvQyxJQUFNLGFBQWEsR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFBO2dCQUM5QyxJQUFJLGFBQWEsRUFBRSxDQUFDO29CQUNsQixJQUFJLEtBQUssRUFBRSxDQUFDO3dCQUNWLEtBQUssR0FBRyxLQUFLLENBQUE7b0JBQ2YsQ0FBQzt5QkFBTSxDQUFDO3dCQUNOLEdBQUcsSUFBSSxJQUFJLEdBQUcsTUFBTSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUE7b0JBQ2xDLENBQUM7b0JBQ0QsR0FBRyxJQUFJLGFBQWEsQ0FBQTtnQkFDdEIsQ0FBQztZQUNILENBQUM7WUFDRCxPQUFPLEdBQUcsR0FBRyxHQUFHLENBQUE7UUFDbEIsS0FBSyxLQUFLO1lBQ1IscURBQXFEO1lBQ3JELHVDQUF1QztZQUN2QyxPQUFPLE9BQU8sR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQTtRQUNqRCxrQkFBa0I7UUFDbEIsS0FBSyxTQUFTO1lBQ1osT0FBTyxhQUFLLE1BQU0sQ0FBQyxRQUFRLGdCQUFLLE1BQU0sQ0FBQyxJQUFJLE1BQUcsQ0FBQTtRQUNoRCxLQUFLLFNBQVM7WUFDWixPQUFPLENBQ0wsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUM7Z0JBQ3JCLFdBQVc7Z0JBQ1gsS0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDckQsT0FBTztnQkFDUCxLQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEtBQUssRUFBRSxNQUFNLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQ3RELENBQUE7UUFDSCxLQUFLLEdBQUcsQ0FBQztRQUNULEtBQUssSUFBSSxDQUFDO1FBQ1YsS0FBSyxHQUFHLENBQUM7UUFDVCxLQUFLLElBQUksQ0FBQztRQUNWLEtBQUssR0FBRyxDQUFDO1FBQ1QsS0FBSyxJQUFJLENBQUM7UUFDVixLQUFLLE1BQU0sQ0FBQztRQUNaLEtBQUssT0FBTztZQUNWLElBQUksUUFBUSxHQUNWLE9BQU8sTUFBTSxDQUFDLFFBQVEsS0FBSyxRQUFRO2dCQUNqQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUM7Z0JBQ3hCLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFBLENBQUMsNkVBQTZFO1lBRWpILElBQUksTUFBTSxDQUFDLEtBQUssS0FBSyxJQUFJLEVBQUUsQ0FBQztnQkFDMUIsT0FBTyxVQUFHLFFBQVEsY0FBSSxNQUFNLENBQUMsSUFBSSxDQUFFLENBQUE7WUFDckMsQ0FBQztZQUVELE9BQU8sVUFBRyxRQUFRLGNBQUksTUFBTSxDQUFDLElBQUksY0FDL0IsTUFBTSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsS0FBSyxJQUFJO2dCQUM5QixDQUFDLENBQUMsV0FBSSxNQUFNLENBQUMsS0FBSyxNQUFHO2dCQUNyQixDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FDdkIsQ0FBQSxDQUFDLG1CQUFtQjtRQUN4QixnQkFBZ0I7UUFDaEIsS0FBSyxVQUFVO1lBQ2IsaUdBQWlHO1lBQ2pHLE9BQU8sVUFBRyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxpQkFBTyxTQUFTLENBQUMsWUFBWSxDQUMxRCxNQUFNLENBQUMsS0FBSyxDQUNiLE1BQUcsQ0FBQTtRQUNOLEtBQUssUUFBUTtZQUNYLE9BQU8sVUFBRyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxjQUFJLFNBQVMsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFFLENBQUE7UUFDekUsS0FBSyxRQUFRLENBQUM7UUFDZCxLQUFLLE9BQU87WUFDVixPQUFPLENBQ0wsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUM7Z0JBQ3JCLEdBQUc7Z0JBQ0gsTUFBTSxDQUFDLElBQUk7Z0JBQ1gsR0FBRztnQkFDSCxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FDOUQsQ0FBQTtRQUNILEtBQUssUUFBUTtZQUNYLE9BQU8sVUFBRyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxjQUFJLE1BQU0sQ0FBQyxJQUFJLGNBQUksTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLGNBQ2xFLE1BQU0sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUNoQixDQUFBO1FBQ0osc0JBQXNCO1FBQ3RCLEtBQUssMkJBQTJCO1lBQzlCLGlGQUFpRjtZQUNqRixPQUFPLG9CQUFhLEtBQUssQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLGNBQUksS0FBSyxDQUNqRCxNQUFNLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FDdEIsY0FBSSxLQUFLLENBQUMsVUFBRyxNQUFNLENBQUMsS0FBSyxDQUFDLEtBQUssY0FBSSxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBRSxDQUFDLGFBQVUsQ0FBQTtZQUNwRSxNQUFLO1FBQ1AsS0FBSyxxQkFBcUI7WUFDeEIsSUFBTSx1QkFBdUIsR0FBRyxNQUFNLENBQUMsS0FBd0IsQ0FBQTtZQUMvRCxJQUFJLHVCQUF1QixDQUFDLEtBQUssRUFBRSxDQUFDO2dCQUNsQyxPQUFNO1lBQ1IsQ0FBQztpQkFBTSxJQUFJLHVCQUF1QixDQUFDLEdBQUcsS0FBSyxFQUFFLEVBQUUsQ0FBQztnQkFDOUMsT0FBTyxxQkFBcUIsQ0FBQTtZQUM5QixDQUFDO2lCQUFNLENBQUM7Z0JBQ04sT0FBTyx1QkFBdUIsQ0FBQyxHQUFHLENBQUE7WUFDcEMsQ0FBQztZQUNELE1BQUs7UUFDUCxLQUFLLFNBQVM7WUFDWixJQUFJLE9BQU8sTUFBTSxLQUFLLFFBQVEsRUFBRSxDQUFDO2dCQUMvQixPQUFPLG9CQUFvQixDQUFDLEdBQUcsR0FBRyxNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQTtZQUNyRSxDQUFDO2lCQUFNLElBQUksT0FBTyxNQUFNLEtBQUssUUFBUSxFQUFFLENBQUM7Z0JBQ3RDLE9BQU8sTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFBO1lBQ3ZCLENBQUM7aUJBQU0sSUFBSSxPQUFPLE1BQU0sS0FBSyxTQUFTLEVBQUUsQ0FBQztnQkFDdkMsT0FBTyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUE7WUFDeEIsQ0FBQztZQUNELE1BQUs7UUFDUDtZQUNFLE1BQU0sSUFBSSxLQUFLLENBQUMsZ0JBQWdCLEdBQUcsTUFBTSxDQUFDLElBQUksR0FBRyxHQUFHLEdBQUcsTUFBTSxDQUFDLENBQUE7SUFDbEUsQ0FBQztBQUNILENBQUM7QUFFRCxTQUFTLGVBQWUsQ0FBQyxNQUEwQjtJQUNqRCxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQztRQUMvQyxJQUFJLFdBQVcsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxFQUFFLENBQUM7WUFDM0MsTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUN6QixNQUFNLENBQUMsT0FBTyxFQUNiLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBVyxDQUFDLE1BQU0sQ0FDckIsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQXdCLENBQUMsT0FBTyxDQUNsRCxDQUNGLENBQUE7UUFDSCxDQUFDO0lBQ0gsQ0FBQztJQUNELE9BQU8sTUFBTSxDQUFBO0FBQ2YsQ0FBQztBQUVEOzs7Ozs7R0FNRztBQUNILFNBQVMsV0FBVyxDQUNsQixNQUF3QyxFQUN4QyxVQUErQjtJQUUvQixJQUFJLENBQUMsb0JBQW9CLENBQUMsTUFBTSxDQUFDLElBQUksVUFBVSxFQUFFLENBQUM7UUFDaEQsT0FBTyxLQUFLLENBQUE7SUFDZCxDQUFDO1NBQU0sSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBQ3ZCLElBQUksb0JBQW9CLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztZQUNqQyxlQUFlLENBQUMsTUFBTSxDQUFDLENBQUE7UUFDekIsQ0FBQztRQUNELE9BQU8sTUFBTSxDQUFBO0lBQ2YsQ0FBQztTQUFNLENBQUM7UUFDTixlQUFlLENBQUMsTUFBNEIsQ0FBQyxDQUFBO1FBQzdDLElBQUksTUFBTSxDQUFDLElBQUksS0FBSyxVQUFVLENBQUMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQ3ZELGdGQUFnRjtZQUNoRixPQUFPLElBQUksQ0FBQTtRQUNiLENBQUM7YUFBTSxDQUFDO1lBQ04sT0FBTyxLQUFLLENBQUE7UUFDZCxDQUFDO0lBQ0gsQ0FBQztBQUNILENBQUM7QUFFRCxTQUFTLGNBQWMsQ0FBQyxFQUl2QjtRQUhDLE1BQU0sWUFBQTtJQUlOLElBQUksb0JBQW9CLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztRQUNqQyxJQUFJLE1BQU0sQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUNuQixPQUFPLElBQUksNkJBQTZCLENBQUM7Z0JBQ3ZDLElBQUksRUFBRSxLQUFLO2dCQUNYLE9BQU8sRUFBRTtvQkFDUCxJQUFJLDZCQUE2QixDQUFDO3dCQUNoQyxJQUFJLEVBQUUsTUFBTSxDQUFDLElBQUk7d0JBQ2pCLE9BQU8sRUFBRSxNQUFNLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxVQUFDLE1BQU07NEJBQ2pDLE9BQUEsY0FBYyxDQUFDLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxDQUFDO3dCQUFsQyxDQUFrQyxDQUNuQztxQkFDRixDQUFDO2lCQUNIO2FBQ0YsQ0FBQyxDQUFBO1FBQ0osQ0FBQzthQUFNLENBQUM7WUFDTixPQUFPLElBQUksNkJBQTZCLENBQUM7Z0JBQ3ZDLElBQUksRUFBRSxNQUFNLENBQUMsSUFBSTtnQkFDakIsT0FBTyxFQUFFLE1BQU0sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLFVBQUMsTUFBTTtvQkFDakMsT0FBQSxjQUFjLENBQUMsRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLENBQUM7Z0JBQWxDLENBQWtDLENBQ25DO2FBQ0YsQ0FBQyxDQUFBO1FBQ0osQ0FBQztJQUNILENBQUM7U0FBTSxDQUFDO1FBQ04sSUFBSSxNQUFNLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDbkIsSUFBTSxpQkFBaUIsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUE7WUFDNUMsT0FBTyxJQUFJLDZCQUE2QixDQUFDO2dCQUN2QyxJQUFJLEVBQUUsS0FBSztnQkFDWCxPQUFPLEVBQUU7b0JBQ1AsSUFBSSw2QkFBNkIsQ0FBQzt3QkFDaEMsSUFBSSxFQUFFLEtBQUs7d0JBQ1gsT0FBTyxFQUFFOzRCQUNQLElBQUksV0FBVyxjQUNWLGlCQUFpQixFQUNwQjt5QkFDSDtxQkFDRixDQUFDO2lCQUNIO2FBQ0YsQ0FBQyxDQUFBO1FBQ0osQ0FBQzthQUFNLENBQUM7WUFDTixPQUFPLE1BQU0sQ0FBQTtRQUNmLENBQUM7SUFDSCxDQUFDO0FBQ0gsQ0FBQztBQUVELFNBQVMsMENBQTBDO0lBQ2pELE9BQU8seUJBQXlCLENBQUM7UUFDL0IsYUFBYSxFQUFFLGdCQUFnQixDQUFDLGFBQWE7UUFDN0MsbUJBQW1CLEVBQUUsZ0JBQWdCLENBQUMsbUJBQW1CO0tBQzFELENBQUMsQ0FBQTtBQUNKLENBQUM7QUFFRCxTQUFTLG9CQUFvQixDQUMzQixNQUF3RTtJQUV4RSxJQUFNLGdCQUFnQixHQUFHLFVBQVUsQ0FBQyxZQUFZO1FBQzlDLENBQUMsQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLGtCQUFrQixDQUFDLE1BQU0sQ0FBQztRQUNwRCxDQUFDLENBQUMsSUFBSSxDQUFBO0lBQ1IsSUFBSSwrQkFBK0IsQ0FBQyxNQUFNLENBQUMsSUFBSSxvQkFBb0IsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO1FBQzVFLE9BQU8sSUFBSSw2QkFBNkIsQ0FBQztZQUN2QyxJQUFJLEVBQUUsTUFBTSxDQUFDLElBQUk7WUFDakIsT0FBTyxFQUFFLE1BQU0sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLFVBQUMsTUFBTSxJQUFLLE9BQUEsb0JBQW9CLENBQUMsTUFBTSxDQUFDLEVBQTVCLENBQTRCLENBQUM7U0FDdEUsQ0FBQyxDQUFBO0lBQ0osQ0FBQztTQUFNLElBQUksb0JBQW9CLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztRQUN4QyxJQUFNLHVCQUFxQixHQUFHLDBDQUEwQyxFQUFFLENBQUE7UUFDMUUsSUFBTSxpQkFBZSxHQUFrQixFQUFFLENBQUE7UUFDekMsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsVUFBQyxLQUFLO1lBQ3JCLElBQU0sa0JBQWtCLEdBQUcsdUJBQXFCLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFBO1lBQ2hFLElBQUksa0JBQWtCLEVBQUUsQ0FBQztnQkFDdkIsTUFBTSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxVQUFVLENBQUMsQ0FBQyxHQUFHLENBQUMsVUFBQyxTQUFTO29CQUN2RCxJQUFNLGNBQWMsR0FBRyxrQkFBa0IsQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLENBQUE7b0JBQy9ELGNBQWMsQ0FBQyxPQUFPLENBQUMsVUFBQyxhQUFhO3dCQUNuQyxpQkFBZSxDQUFDLElBQUksQ0FDbEIsSUFBSSxXQUFXLENBQUM7NEJBQ2QsUUFBUSxFQUFFLFNBQVM7NEJBQ25CLEtBQUssRUFBRSxhQUFhOzRCQUNwQixJQUFJLEVBQUUsT0FBTzt5QkFDZCxDQUFDLENBQ0gsQ0FBQTtvQkFDSCxDQUFDLENBQUMsQ0FBQTtnQkFDSixDQUFDLENBQUMsQ0FBQTtZQUNKLENBQUM7UUFDSCxDQUFDLENBQUMsQ0FBQTtRQUNGLE9BQU8sSUFBSSw2QkFBNkIsQ0FBQztZQUN2QyxJQUFJLEVBQUUsS0FBSztZQUNYLE9BQU8sRUFBRTtnQkFDUCxJQUFJLDZCQUE2QixDQUFDO29CQUNoQyxJQUFJLEVBQUUsSUFBSTtvQkFDVixPQUFPLEVBQUUsaUJBQWU7aUJBQ3pCLENBQUM7YUFDSDtTQUNGLENBQUMsQ0FBQTtJQUNKLENBQUM7U0FBTSxJQUFJLGdCQUFnQixFQUFFLENBQUM7UUFDNUIsT0FBTyxnQkFBZ0IsQ0FBQTtJQUN6QixDQUFDO1NBQU0sSUFBSSx5QkFBeUIsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO1FBQzdDLElBQU0sVUFBVSxHQUFHLDBDQUEwQyxDQUFDLE1BQU0sQ0FBQyxDQUFBO1FBQ3JFLE9BQU8sSUFBSSxXQUFXLHVCQUNqQixNQUFNLEtBQ1QsS0FBSyxFQUFFLFVBQVUsSUFDakIsQ0FBQTtJQUNKLENBQUM7U0FBTSxJQUFJLDhCQUE4QixDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUM7UUFDbEQsSUFBTSxVQUFVLEdBQUcsK0NBQStDLENBQUMsTUFBTSxDQUFDLENBQUE7UUFDMUUsT0FBTyxJQUFJLFdBQVcsdUJBQ2pCLE1BQU0sS0FDVCxLQUFLLEVBQUUsVUFBVSxJQUNqQixDQUFBO0lBQ0osQ0FBQztTQUFNLENBQUM7UUFDTixPQUFPLE1BQU0sQ0FBQTtJQUNmLENBQUM7QUFDSCxDQUFDO0FBRUQ7Ozs7O0dBS0c7QUFDSCxTQUFTLG9CQUFvQixDQUMzQixNQUF3RTtJQUV4RSxpR0FBaUc7SUFDakcsSUFDRSxvQkFBb0IsQ0FBQyxNQUFNLENBQUM7UUFDNUIsMEJBQTBCLENBQUMsTUFBTSxDQUFDO1FBQ2xDLCtCQUErQixDQUFDLE1BQU0sQ0FBQyxFQUN2QyxDQUFDO1FBQ0QsSUFBSSxDQUFDLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUE7UUFDN0IsT0FBTyxDQUFDLEVBQUUsRUFBRSxDQUFDO1lBQ1gsSUFBTSxhQUFhLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQTtZQUN2QyxJQUFNLFdBQVcsR0FBRyxvQkFBb0IsQ0FBQyxhQUFhLENBQUMsQ0FBQTtZQUN2RCxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7Z0JBQ2pCLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQTtZQUM3QixDQUFDO1FBQ0gsQ0FBQztRQUNELElBQUksTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFLENBQUM7WUFDaEMsT0FBTyxLQUFLLENBQUE7UUFDZCxDQUFDO0lBQ0gsQ0FBQztTQUFNLENBQUM7UUFDTixJQUFJLE1BQU0sQ0FBQyxRQUFRLEtBQUssU0FBUyxFQUFFLENBQUM7WUFDbEMsT0FBTyxLQUFLLENBQUE7UUFDZCxDQUFDO1FBQ0QsSUFBSSxNQUFNLENBQUMsSUFBSSxLQUFLLHFCQUFxQixFQUFFLENBQUM7WUFDMUMsSUFBTSxnQkFBZ0IsR0FBRyxNQUFNLENBQUMsS0FBd0IsQ0FBQTtZQUN4RCxJQUFJLGdCQUFnQixDQUFDLEtBQUssRUFBRSxDQUFDO2dCQUMzQixPQUFPLEtBQUssQ0FBQTtZQUNkLENBQUM7UUFDSCxDQUFDO0lBQ0gsQ0FBQztJQUNELE9BQU8sTUFBTSxDQUFBO0FBQ2YsQ0FBQztBQUVELFNBQVMsbUJBQW1CLENBQUMsTUFBMEI7SUFDckQsSUFBSSxPQUFPLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFBO0lBQ2hDLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQTtJQUNuQixPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLEtBQUssSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO1FBQzFELE9BQU8sR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUE7UUFDNUIsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFBO0lBQ3JCLENBQUM7SUFDRCxPQUFPLE1BQU0sQ0FBQTtBQUNmLENBQUM7QUFFRCxlQUFlO0lBQ2I7Ozs7Ozs7O09BUUc7SUFDSCxJQUFJLFlBQUMsR0FBWTtRQUNmLElBQUksR0FBRyxLQUFLLFNBQVMsSUFBSSxHQUFHLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRSxDQUFDO1lBQzFDLE9BQU8sSUFBSSxrQkFBa0IsQ0FBQztnQkFDNUIsSUFBSSxFQUFFLEtBQUs7Z0JBQ1gsT0FBTyxFQUFFLEVBQUU7YUFDWixDQUFDLENBQUE7UUFDSixDQUFDO1FBQ0QsMkZBQTJGO1FBQzNGLElBQUksQ0FBQztZQUNILElBQU0sbUJBQW1CLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQTtZQUNsRSxJQUNFLG9CQUFvQixDQUFDLG1CQUFtQixDQUFDO2dCQUN6QywwQkFBMEIsQ0FBQyxtQkFBbUIsQ0FBQyxFQUMvQyxDQUFDO2dCQUNELE9BQU8sSUFBSSxrQkFBa0IsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFBO1lBQ3BELENBQUM7aUJBQU0sQ0FBQztnQkFDTixPQUFPLElBQUksa0JBQWtCLENBQUM7b0JBQzVCLElBQUksRUFBRSxLQUFLO29CQUNYLE9BQU8sRUFBRSxDQUFDLG1CQUFrQyxDQUFDO2lCQUM5QyxDQUFDLENBQUE7WUFDSixDQUFDO1FBQ0gsQ0FBQztRQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7WUFDYixPQUFPLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFBO1lBQ2xCLE9BQU8sSUFBSSxrQkFBa0IsQ0FBQyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsT0FBTyxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUE7UUFDN0QsQ0FBQztJQUNILENBQUM7SUFDRCxLQUFLLFlBQUMsTUFBMEI7UUFDOUIsSUFBSSxDQUFDO1lBQ0gsSUFBTSxjQUFjLEdBQUcsb0JBQW9CLENBQ3pDLGNBQWMsQ0FBQztnQkFDYixNQUFNLEVBQUUsTUFBTTthQUNmLENBQUMsQ0FDSCxDQUFBO1lBQ0Qsb0JBQW9CLENBQUMsY0FBYyxDQUFDLENBQUE7WUFDcEMsT0FBTyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUE7UUFDOUIsQ0FBQztRQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7WUFDYixPQUFPLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFBO1lBQ2xCLE9BQU8sS0FBSyxDQUNWLElBQUksa0JBQWtCLENBQUM7Z0JBQ3JCLElBQUksRUFBRSxLQUFLO2dCQUNYLE9BQU8sRUFBRSxFQUFFO2FBQ1osQ0FBQyxDQUNILENBQUE7UUFDSCxDQUFDO0lBQ0gsQ0FBQztJQUNELG9CQUFvQixzQkFBQTtJQUNwQixRQUFRLFlBQUMsTUFBMEI7UUFDakMsT0FBTyxtQkFBbUIsQ0FBQyxNQUFNLENBQUMsQ0FBQTtJQUNwQyxDQUFDO0lBQ0Qsb0JBQW9CLHNCQUFBO0lBQ3BCLG9CQUFvQixzQkFBQTtJQUNwQixnQkFBZ0Isa0JBQUE7SUFDaEIsYUFBYSxlQUFBO0NBQ2QsQ0FBQSIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQ29weXJpZ2h0IChjKSBDb2RpY2UgRm91bmRhdGlvblxuICpcbiAqIFRoaXMgaXMgZnJlZSBzb2Z0d2FyZTogeW91IGNhbiByZWRpc3RyaWJ1dGUgaXQgYW5kL29yIG1vZGlmeSBpdCB1bmRlciB0aGUgdGVybXMgb2YgdGhlIEdOVSBMZXNzZXJcbiAqIEdlbmVyYWwgUHVibGljIExpY2Vuc2UgYXMgcHVibGlzaGVkIGJ5IHRoZSBGcmVlIFNvZnR3YXJlIEZvdW5kYXRpb24sIGVpdGhlciB2ZXJzaW9uIDMgb2YgdGhlXG4gKiBMaWNlbnNlLCBvciBhbnkgbGF0ZXIgdmVyc2lvbi5cbiAqXG4gKiBUaGlzIHByb2dyYW0gaXMgZGlzdHJpYnV0ZWQgaW4gdGhlIGhvcGUgdGhhdCBpdCB3aWxsIGJlIHVzZWZ1bCwgYnV0IFdJVEhPVVQgQU5ZIFdBUlJBTlRZOyB3aXRob3V0XG4gKiBldmVuIHRoZSBpbXBsaWVkIHdhcnJhbnR5IG9mIE1FUkNIQU5UQUJJTElUWSBvciBGSVRORVNTIEZPUiBBIFBBUlRJQ1VMQVIgUFVSUE9TRS4gU2VlIHRoZSBHTlVcbiAqIExlc3NlciBHZW5lcmFsIFB1YmxpYyBMaWNlbnNlIGZvciBtb3JlIGRldGFpbHMuIEEgY29weSBvZiB0aGUgR05VIExlc3NlciBHZW5lcmFsIFB1YmxpYyBMaWNlbnNlXG4gKiBpcyBkaXN0cmlidXRlZCBhbG9uZyB3aXRoIHRoaXMgcHJvZ3JhbSBhbmQgY2FuIGJlIGZvdW5kIGF0XG4gKiA8aHR0cDovL3d3dy5nbnUub3JnL2xpY2Vuc2VzL2xncGwuaHRtbD4uXG4gKlxuICoqL1xuLyogQ29weXJpZ2h0IChjKSAyMDA2LTIwMTUgYnkgT3BlbkxheWVycyBDb250cmlidXRvcnMgKHNlZSBhdXRob3JzLnR4dCBmb3JcbiAqIGZ1bGwgbGlzdCBvZiBjb250cmlidXRvcnMpLiBQdWJsaXNoZWQgdW5kZXIgdGhlIDItY2xhdXNlIEJTRCBsaWNlbnNlLlxuICogU2VlIGxpY2Vuc2UudHh0IGluIHRoZSBPcGVuTGF5ZXJzIGRpc3RyaWJ1dGlvbiBvciByZXBvc2l0b3J5IGZvciB0aGVcbiAqIGZ1bGwgdGV4dCBvZiB0aGUgbGljZW5zZS4gKi9cbmltcG9ydCB7XG4gIEJvb2xlYW5UZXh0VHlwZSxcbiAgQ1FMU3RhbmRhcmRGaWx0ZXJCdWlsZGVyQ2xhc3MsXG4gIGRlc2VyaWFsaXplLFxuICBGaWx0ZXJCdWlsZGVyQ2xhc3MsXG4gIEZpbHRlckNsYXNzLFxuICBpc0Jhc2ljRGF0YXR5cGVDbGFzcyxcbiAgaXNGaWx0ZXJCdWlsZGVyQ2xhc3MsXG4gIGlzQ1FMU3RhbmRhcmRGaWx0ZXJCdWlsZGVyQ2xhc3MsXG4gIHNlcmlhbGl6ZSxcbiAgc2hvdWxkQmVGaWx0ZXJCdWlsZGVyQ2xhc3MsXG4gIFZhbHVlVHlwZXMsXG4gIGNvbnZlcnRSZXNvdXJjZVNpemVGaWx0ZXJDbGFzc1ZhbHVlVG9CeXRlcyxcbiAgaXNSZXNvdXJjZVNpemVGaWx0ZXJDbGFzcyxcbiAgaXNSZXNvdXJjZVNpemVSYW5nZUZpbHRlckNsYXNzLFxuICBjb252ZXJ0UmVzb3VyY2VTaXplUmFuZ2VGaWx0ZXJDbGFzc1ZhbHVlVG9CeXRlcyxcbn0gZnJvbSAnLi4vY29tcG9uZW50L2ZpbHRlci1idWlsZGVyL2ZpbHRlci5zdHJ1Y3R1cmUnXG5pbXBvcnQgeyBnZXREYXRhVHlwZXNDb25maWd1cmF0aW9uIH0gZnJvbSAnLi4vY29tcG9uZW50L3Jlc2VydmVkLWJhc2ljLWRhdGF0eXBlL3Jlc2VydmVkLmJhc2ljLWRhdGF0eXBlJ1xuaW1wb3J0IENRTFV0aWxzIGZyb20gJy4vQ1FMVXRpbHMnXG5pbXBvcnQgX2Nsb25lRGVlcCBmcm9tICdsb2Rhc2gvY2xvbmVEZWVwJ1xuaW1wb3J0IHdreCBmcm9tICd3a3gnXG5pbXBvcnQgeyBTdGFydHVwRGF0YVN0b3JlIH0gZnJvbSAnLi9tb2RlbC9TdGFydHVwL3N0YXJ0dXAnXG5pbXBvcnQgRXh0ZW5zaW9ucyBmcm9tICcuLi9leHRlbnNpb24tcG9pbnRzJ1xuXG5jb25zdCBnZXRQb2ludFJhZGl1c0ZpbHRlciA9IChcbiAgcG9pbnQ6IFtudW1iZXIsIG51bWJlcl0sXG4gIHByb3BlcnR5OiBzdHJpbmcsXG4gIHJhZGl1cz86IHN0cmluZ1xuKSA9PiB7XG4gIGNvbnN0IHZhbHVlID0ge1xuICAgIG1vZGU6ICdjaXJjbGUnLFxuICAgIHR5cGU6ICdQT0lOVFJBRElVUycsXG4gICAgbGF0OiBwb2ludFsxXSxcbiAgICBsb246IHBvaW50WzBdLFxuICB9XG5cbiAgcmV0dXJuIG5ldyBGaWx0ZXJDbGFzcyh7XG4gICAgdHlwZTogJ0dFT01FVFJZJyxcbiAgICB2YWx1ZTogKHJhZGl1cyA/IHsgLi4udmFsdWUsIHJhZGl1cyB9IDogdmFsdWUpIGFzIFZhbHVlVHlwZXNbJ2xvY2F0aW9uJ10sXG4gICAgcHJvcGVydHksXG4gIH0pXG59XG5cbmNvbnN0IGdldExpbmVzdHJpbmdGaWx0ZXIgPSAoXG4gIGxpbmU6IG51bWJlcltdW10sXG4gIHByb3BlcnR5OiBzdHJpbmcsXG4gIGJ1ZmZlcj86IHN0cmluZ1xuKSA9PiB7XG4gIGNvbnN0IHZhbHVlID0ge1xuICAgIG1vZGU6ICdsaW5lJyxcbiAgICB0eXBlOiAnTElORScsXG4gICAgbGluZTogbGluZSxcbiAgfVxuXG4gIHJldHVybiBuZXcgRmlsdGVyQ2xhc3Moe1xuICAgIHR5cGU6ICdHRU9NRVRSWScsXG4gICAgdmFsdWU6IChidWZmZXJcbiAgICAgID8geyAuLi52YWx1ZSwgbGluZVdpZHRoOiBidWZmZXIgfVxuICAgICAgOiB2YWx1ZSkgYXMgVmFsdWVUeXBlc1snbG9jYXRpb24nXSxcbiAgICBwcm9wZXJ0eSxcbiAgfSlcbn1cblxuY29uc3QgZ2V0UG9seWdvbkZpbHRlciA9IChcbiAgcG9seTogbnVtYmVyW11bXSxcbiAgcHJvcGVydHk6IHN0cmluZyxcbiAgYnVmZmVyPzogc3RyaW5nXG4pID0+IHtcbiAgY29uc3QgdmFsdWUgPSB7XG4gICAgbW9kZTogJ3BvbHknLFxuICAgIHR5cGU6ICdQT0xZR09OJyxcbiAgICBwb2x5Z29uOiBwb2x5LFxuICB9XG5cbiAgcmV0dXJuIG5ldyBGaWx0ZXJDbGFzcyh7XG4gICAgdHlwZTogJ0dFT01FVFJZJyxcbiAgICB2YWx1ZTogKGJ1ZmZlclxuICAgICAgPyB7IC4uLnZhbHVlLCBwb2x5Z29uQnVmZmVyV2lkdGg6IGJ1ZmZlciB9XG4gICAgICA6IHZhbHVlKSBhcyBWYWx1ZVR5cGVzWydsb2NhdGlvbiddLFxuICAgIHByb3BlcnR5LFxuICB9KVxufVxuY29uc3QgQU5ZVEVYVF9XSUxEQ0FSRCA9ICdcImFueVRleHRcIiBJTElLRSBcXCclXFwnJ1xudHlwZSBQcmVjZW5kZW5jZVR5cGUgPSAnUlBBUkVOJyB8ICdMT0dJQ0FMJyB8ICdDT01QQVJJU09OJ1xudHlwZSBGaWx0ZXJGdW5jdGlvbk5hbWVzID0gJ3Byb3hpbWl0eScgfCAncGknXG50eXBlIFBhdHRlcm5SZXR1cm5UeXBlID0gUmVnRXhwIHwgKCh0ZXh0OiBzdHJpbmcpID0+IHN0cmluZ1tdIHwgbnVsbClcblxudHlwZSBQYXR0ZXJuTmFtZXNUeXBlID1cbiAgfCAnUFJPUEVSVFknXG4gIHwgJ0NPTVBBUklTT04nXG4gIHwgJ0lTX05VTEwnXG4gIHwgJ0NPTU1BJ1xuICB8ICdMT0dJQ0FMJ1xuICB8ICdWQUxVRSdcbiAgfCAnRklMVEVSX0ZVTkNUSU9OJ1xuICB8ICdCT09MRUFOJ1xuICB8ICdMUEFSRU4nXG4gIHwgJ1JQQVJFTidcbiAgfCAnU1BBVElBTCdcbiAgfCAnVU5JVFMnXG4gIHwgJ05PVCdcbiAgfCAnQkVUV0VFTidcbiAgfCAnQkVGT1JFJ1xuICB8ICdBRlRFUidcbiAgfCAnRFVSSU5HJ1xuICB8ICdSRUxBVElWRSdcbiAgfCAnVElNRSdcbiAgfCAnVElNRV9QRVJJT0QnXG4gIHwgJ0dFT01FVFJZJ1xuXG5jb25zdCB0aW1lUGF0dGVybiA9XG4gICAgLygoKFswLTldezR9KSgtKFswLTldezJ9KSgtKFswLTldezJ9KShUKFswLTldezJ9KTooWzAtOV17Mn0pKDooWzAtOV17Mn0pKFxcLihbMC05XSspKT8pPyhafCgoWy0rXSkoWzAtOV17Mn0pOihbMC05XXsyfSkpKT8pPyk/KT8pfF4nJykvaSxcbiAgcGF0dGVybnMgPSB7XG4gICAgLy9BbGxvd3MgZm9yIG5vbi1zdGFuZGFyZCBzaW5nbGUtcXVvdGVkIHByb3BlcnR5IG5hbWVzXG4gICAgUFJPUEVSVFk6IC9eKFtfYS16QS1aXVxcdyp8XCJbXlwiXStcInwnW14nXSsnKS8sXG4gICAgQ09NUEFSSVNPTjogL14oPXw8Pnw8PXw8fD49fD58TElLRXxJTElLRSkvaSxcbiAgICBJU19OVUxMOiAvXklTIE5VTEwvaSxcbiAgICBDT01NQTogL14sLyxcbiAgICBMT0dJQ0FMOiAvXihBTkR8T1IpL2ksXG4gICAgVkFMVUU6IC9eKCcoW14nXXwnJykqJ3wtP1xcZCsoXFwuXFxkKik/fFxcLlxcZCspLyxcbiAgICBGSUxURVJfRlVOQ1RJT046IC9eW2Etel1cXHcrXFwoLyxcbiAgICBCT09MRUFOOiAvXihmYWxzZXx0cnVlKS9pLFxuICAgIExQQVJFTjogL15cXCgvLFxuICAgIFJQQVJFTjogL15cXCkvLFxuICAgIFNQQVRJQUw6IC9eKEJCT1h8SU5URVJTRUNUU3xEV0lUSElOfFdJVEhJTnxDT05UQUlOUykvaSxcbiAgICBVTklUUzogL14obWV0ZXJzKS9pLFxuICAgIE5PVDogL15OT1QvaSxcbiAgICBCRVRXRUVOOiAvXkJFVFdFRU4vaSxcbiAgICBCRUZPUkU6IC9eQkVGT1JFL2ksXG4gICAgQUZURVI6IC9eQUZURVIvaSxcbiAgICBEVVJJTkc6IC9eRFVSSU5HL2ksXG4gICAgUkVMQVRJVkU6IC9eJ1JFTEFUSVZFXFwoW0EtWmEtejAtOS5dKlxcKScvaSxcbiAgICBUSU1FOiBuZXcgUmVnRXhwKCdeJyArIHRpbWVQYXR0ZXJuLnNvdXJjZSksXG4gICAgVElNRV9QRVJJT0Q6IG5ldyBSZWdFeHAoXG4gICAgICAnXicgKyB0aW1lUGF0dGVybi5zb3VyY2UgKyAnLycgKyB0aW1lUGF0dGVybi5zb3VyY2VcbiAgICApLFxuICAgIEdFT01FVFJZKHRleHQ6IHN0cmluZykge1xuICAgICAgY29uc3QgdHlwZSA9XG4gICAgICAgIC9eKFBPSU5UfExJTkVTVFJJTkd8UE9MWUdPTnxNVUxUSVBPSU5UfE1VTFRJTElORVNUUklOR3xNVUxUSVBPTFlHT058R0VPTUVUUllDT0xMRUNUSU9OKS8uZXhlYyhcbiAgICAgICAgICB0ZXh0XG4gICAgICAgIClcbiAgICAgIGlmICh0eXBlKSB7XG4gICAgICAgIGNvbnN0IGxlbiA9IHRleHQubGVuZ3RoXG4gICAgICAgIGxldCBpZHggPSB0ZXh0LmluZGV4T2YoJygnLCB0eXBlWzBdLmxlbmd0aClcbiAgICAgICAgaWYgKGlkeCA+IC0xKSB7XG4gICAgICAgICAgbGV0IGRlcHRoID0gMVxuICAgICAgICAgIHdoaWxlIChpZHggPCBsZW4gJiYgZGVwdGggPiAwKSB7XG4gICAgICAgICAgICBpZHgrK1xuICAgICAgICAgICAgc3dpdGNoICh0ZXh0LmNoYXJBdChpZHgpKSB7XG4gICAgICAgICAgICAgIGNhc2UgJygnOlxuICAgICAgICAgICAgICAgIGRlcHRoKytcbiAgICAgICAgICAgICAgICBicmVha1xuICAgICAgICAgICAgICBjYXNlICcpJzpcbiAgICAgICAgICAgICAgICBkZXB0aC0tXG4gICAgICAgICAgICAgICAgYnJlYWtcbiAgICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgLy8gaW4gZGVmYXVsdCBjYXNlLCBkbyBub3RoaW5nXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBbdGV4dC5zdWJzdHIoMCwgaWR4ICsgMSldXG4gICAgICB9XG4gICAgICByZXR1cm4gbnVsbFxuICAgIH0sXG4gICAgRU5EOiAvXiQvLFxuICB9IGFzIFJlY29yZDxQYXR0ZXJuTmFtZXNUeXBlIHwgJ0VORCcsIFBhdHRlcm5SZXR1cm5UeXBlPixcbiAgZm9sbG93cyA9IHtcbiAgICBST09UX05PREU6IFtcbiAgICAgICdOT1QnLFxuICAgICAgJ0dFT01FVFJZJyxcbiAgICAgICdTUEFUSUFMJyxcbiAgICAgICdGSUxURVJfRlVOQ1RJT04nLFxuICAgICAgJ1BST1BFUlRZJyxcbiAgICAgICdMUEFSRU4nLFxuICAgIF0sXG4gICAgTFBBUkVOOiBbXG4gICAgICAnTk9UJyxcbiAgICAgICdHRU9NRVRSWScsXG4gICAgICAnU1BBVElBTCcsXG4gICAgICAnRklMVEVSX0ZVTkNUSU9OJyxcbiAgICAgICdQUk9QRVJUWScsXG4gICAgICAnVkFMVUUnLFxuICAgICAgJ0xQQVJFTicsXG4gICAgXSxcbiAgICBSUEFSRU46IFsnTk9UJywgJ0xPR0lDQUwnLCAnRU5EJywgJ1JQQVJFTicsICdDT01QQVJJU09OJywgJ0NPTU1BJ10sXG4gICAgUFJPUEVSVFk6IFtcbiAgICAgICdDT01QQVJJU09OJyxcbiAgICAgICdCRVRXRUVOJyxcbiAgICAgICdDT01NQScsXG4gICAgICAnSVNfTlVMTCcsXG4gICAgICAnQkVGT1JFJyxcbiAgICAgICdBRlRFUicsXG4gICAgICAnRFVSSU5HJyxcbiAgICAgICdSUEFSRU4nLFxuICAgIF0sXG4gICAgQkVUV0VFTjogWydWQUxVRSddLFxuICAgIElTX05VTEw6IFsnUlBBUkVOJywgJ0xPR0lDQUwnLCAnWycsICddJ10sXG4gICAgQ09NUEFSSVNPTjogWydSRUxBVElWRScsICdWQUxVRScsICdCT09MRUFOJ10sXG4gICAgQ09NTUE6IFsnRklMVEVSX0ZVTkNUSU9OJywgJ0dFT01FVFJZJywgJ1ZBTFVFJywgJ1VOSVRTJywgJ1BST1BFUlRZJ10sXG4gICAgVkFMVUU6IFsnTE9HSUNBTCcsICdDT01NQScsICdSUEFSRU4nLCAnRU5EJ10sXG4gICAgQk9PTEVBTjogWydSUEFSRU4nXSxcbiAgICBTUEFUSUFMOiBbJ0xQQVJFTiddLFxuICAgIFVOSVRTOiBbJ1JQQVJFTiddLFxuICAgIExPR0lDQUw6IFtcbiAgICAgICdGSUxURVJfRlVOQ1RJT04nLFxuICAgICAgJ05PVCcsXG4gICAgICAnVkFMVUUnLFxuICAgICAgJ1NQQVRJQUwnLFxuICAgICAgJ1BST1BFUlRZJyxcbiAgICAgICdMUEFSRU4nLFxuICAgIF0sXG4gICAgTk9UOiBbJ1BST1BFUlRZJywgJ0xQQVJFTiddLFxuICAgIEdFT01FVFJZOiBbJ0NPTU1BJywgJ1JQQVJFTiddLFxuICAgIEJFRk9SRTogWydUSU1FJ10sXG4gICAgQUZURVI6IFsnVElNRSddLFxuICAgIERVUklORzogWydUSU1FX1BFUklPRCddLFxuICAgIFRJTUU6IFsnTE9HSUNBTCcsICdSUEFSRU4nLCAnRU5EJ10sXG4gICAgVElNRV9QRVJJT0Q6IFsnTE9HSUNBTCcsICdSUEFSRU4nLCAnRU5EJ10sXG4gICAgUkVMQVRJVkU6IFsnUlBBUkVOJywgJ0VORCddLFxuICAgIEZJTFRFUl9GVU5DVElPTjogWydMUEFSRU4nLCAnUFJPUEVSVFknLCAnVkFMVUUnLCAnUlBBUkVOJ10sXG4gICAgRU5EOiBbXSxcbiAgfSBhcyBSZWNvcmQ8XG4gICAgUGF0dGVybk5hbWVzVHlwZSB8ICdST09UX05PREUnIHwgJ0VORCcsXG4gICAgQXJyYXk8UGF0dGVybk5hbWVzVHlwZSB8ICdFTkQnPlxuICA+LFxuICBwcmVjZWRlbmNlID0ge1xuICAgIFJQQVJFTjogMyxcbiAgICBMT0dJQ0FMOiAyLFxuICAgIENPTVBBUklTT046IDEsXG4gIH0gYXMgUmVjb3JkPFByZWNlbmRlbmNlVHlwZSwgbnVtYmVyPixcbiAgLy8gYXMgYW4gaW1wcm92ZW1lbnQsIHRoZXNlIGNvdWxkIGJlIGZpZ3VyZWQgb3V0IHdoaWxlIGJ1aWxkaW5nIHRoZSBzeW50YXggdHJlZVxuICBmaWx0ZXJGdW5jdGlvblBhcmFtQ291bnQgPSB7XG4gICAgcHJveGltaXR5OiAzLFxuICAgIHBpOiAwLFxuICB9IGFzIFJlY29yZDxGaWx0ZXJGdW5jdGlvbk5hbWVzLCBudW1iZXI+LFxuICBkYXRlVGltZUZvcm1hdCA9IFwieXl5eS1NTS1kZCdUJ0hIOm1tOnNzLlNTUydaJ1wiXG5cbmZ1bmN0aW9uIHRyeVRva2VuKHRleHQ6IHN0cmluZywgcGF0dGVybjogUGF0dGVyblJldHVyblR5cGUpIHtcbiAgaWYgKHBhdHRlcm4gaW5zdGFuY2VvZiBSZWdFeHApIHtcbiAgICByZXR1cm4gcGF0dGVybi5leGVjKHRleHQpXG4gIH0gZWxzZSB7XG4gICAgcmV0dXJuIHBhdHRlcm4odGV4dClcbiAgfVxufVxuXG5mdW5jdGlvbiBuZXh0VG9rZW4odGV4dDogc3RyaW5nLCB0b2tlbnM6IEFycmF5PFBhdHRlcm5OYW1lc1R5cGUgfCAnRU5EJz4pIHtcbiAgbGV0IGksXG4gICAgdG9rZW4sXG4gICAgbGVuID0gdG9rZW5zLmxlbmd0aFxuICBmb3IgKGkgPSAwOyBpIDwgbGVuOyBpKyspIHtcbiAgICB0b2tlbiA9IHRva2Vuc1tpXVxuICAgIGNvbnN0IHBhdCA9IHBhdHRlcm5zW3Rva2VuXVxuICAgIGNvbnN0IG1hdGNoZXMgPSB0cnlUb2tlbih0ZXh0LCBwYXQpXG4gICAgaWYgKG1hdGNoZXMpIHtcbiAgICAgIGNvbnN0IG1hdGNoID0gbWF0Y2hlc1swXVxuICAgICAgY29uc3QgcmVtYWluZGVyID0gdGV4dC5zdWJzdHIobWF0Y2gubGVuZ3RoKS5yZXBsYWNlKC9eXFxzKi8sICcnKVxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgdHlwZTogdG9rZW4sXG4gICAgICAgIHRleHQ6IG1hdGNoLFxuICAgICAgICByZW1haW5kZXIsXG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgbGV0IG1zZyA9ICdFUlJPUjogSW4gcGFyc2luZzogWycgKyB0ZXh0ICsgJ10sIGV4cGVjdGVkIG9uZSBvZjogJ1xuICBmb3IgKGkgPSAwOyBpIDwgbGVuOyBpKyspIHtcbiAgICB0b2tlbiA9IHRva2Vuc1tpXVxuICAgIG1zZyArPSAnXFxuICAgICcgKyB0b2tlbiArICc6ICcgKyBwYXR0ZXJuc1t0b2tlbl1cbiAgfVxuXG4gIHRocm93IG5ldyBFcnJvcihtc2cpXG59XG5cbnR5cGUgVG9rZW5UeXBlID0ge1xuICB0eXBlOiBQYXR0ZXJuTmFtZXNUeXBlIHwgJ0VORCdcbiAgdGV4dDogc3RyaW5nXG4gIHJlbWFpbmRlcjogc3RyaW5nXG59XG5cbmZ1bmN0aW9uIHRva2VuaXplKHRleHQ6IHN0cmluZyk6IEFycmF5PFRva2VuVHlwZT4ge1xuICBjb25zdCByZXN1bHRzID0gW11cbiAgbGV0IHRva2VuID0gdW5kZWZpbmVkIGFzIHVuZGVmaW5lZCB8IFRva2VuVHlwZVxuICBsZXQgZXhwZWN0ID0gZm9sbG93c1snUk9PVF9OT0RFJ11cblxuICBkbyB7XG4gICAgdG9rZW4gPSBuZXh0VG9rZW4odGV4dCwgZXhwZWN0KVxuICAgIHRleHQgPSB0b2tlbi5yZW1haW5kZXJcbiAgICBleHBlY3QgPSBmb2xsb3dzW3Rva2VuLnR5cGVdXG4gICAgaWYgKHRva2VuLnR5cGUgIT09ICdFTkQnICYmICFleHBlY3QpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignTm8gZm9sbG93cyBsaXN0IGZvciAnICsgdG9rZW4udHlwZSlcbiAgICB9XG4gICAgcmVzdWx0cy5wdXNoKHRva2VuKVxuICB9IHdoaWxlICh0b2tlbi50eXBlICE9PSAnRU5EJylcbiAgcmV0dXJuIHJlc3VsdHNcbn1cblxudHlwZSBTcGVjaWFsQ1FMQ2hhcmFjdGVycyA9ICclJyB8ICdfJ1xuXG4vLyBNYXBwaW5nIG9mIEludHJpZ3VlJ3MgcXVlcnkgbGFuZ3VhZ2Ugc3ludGF4IHRvIENRTCBzeW50YXhcbmNvbnN0IHVzZXJxbFRvQ3FsID0ge1xuICAnKic6ICclJyxcbiAgJz8nOiAnXycsXG4gICclJzogJ1xcXFwlJyxcbiAgXzogJ1xcXFxfJyxcbn1cblxuY29uc3QgdHJhbnNsYXRlVXNlcnFsVG9DcWwgPSAoc3RyOiBzdHJpbmcpOiBzdHJpbmcgPT5cbiAgc3RyLnJlcGxhY2UoXG4gICAgLyhbXio/JV9dKT8oWyo/JV9dKS9nLFxuICAgIChfLCBhID0gJycsIGIpID0+XG4gICAgICBhICsgKGEgPT09ICdcXFxcJyA/IGIgOiB1c2VycWxUb0NxbFtiIGFzIFNwZWNpYWxDUUxDaGFyYWN0ZXJzXSlcbiAgKVxuXG4vL01hcHBpbmcgb2YgQ1FMIHN5bnRheCB0byBJbnRyaWd1ZSdzIHF1ZXJ5IGxhbmd1YWdlIHN5bnRheFxuY29uc3QgY3FsVG9Vc2VycWwgPSB7XG4gICclJzogJyonLFxuICBfOiAnPycsXG59IGFzIFJlY29yZDxTcGVjaWFsQ1FMQ2hhcmFjdGVycywgc3RyaW5nPlxuXG5jb25zdCB0cmFuc2xhdGVDcWxUb1VzZXJxbCA9IChzdHI6IHN0cmluZyk6IHN0cmluZyA9PlxuICBzdHIucmVwbGFjZSgvKFteJV9dKT8oWyVfXSkvZywgKF8sIGEgPSAnJywgYikgPT5cbiAgICBhID09PSAnXFxcXCcgPyBiIDogYSArIGNxbFRvVXNlcnFsW2IgYXMgU3BlY2lhbENRTENoYXJhY3RlcnNdXG4gIClcblxuY29uc3QgZ2V0TmV4dFRva2VuID0gKHBvc3RmaXg6IEFycmF5PFRva2VuVHlwZT4pOiBUb2tlblR5cGUgPT4ge1xuICBpZiAoXG4gICAgcG9zdGZpeFtwb3N0Zml4Lmxlbmd0aCAtIDNdICYmXG4gICAgcG9zdGZpeFtwb3N0Zml4Lmxlbmd0aCAtIDNdLnR5cGUgPT09ICdGSUxURVJfRlVOQ1RJT04nXG4gICkge1xuICAgIC8vIGZpcnN0IHR3byBhcmUgdXNlbGVzc1xuICAgIHBvc3RmaXgucG9wKClcbiAgICBwb3N0Zml4LnBvcCgpXG4gICAgcmV0dXJuIHBvc3RmaXgucG9wKCkgYXMgVG9rZW5UeXBlXG4gIH1cbiAgaWYgKFxuICAgIHBvc3RmaXhbcG9zdGZpeC5sZW5ndGggLSAyXSAmJlxuICAgIHBvc3RmaXhbcG9zdGZpeC5sZW5ndGggLSAyXS50eXBlID09PSAnUkVMQVRJVkUnXG4gICkge1xuICAgIC8vIGZpcnN0IG9uZSBpcyB1c2VsZXNzXG4gICAgcG9zdGZpeC5wb3AoKVxuICAgIHJldHVybiBwb3N0Zml4LnBvcCgpIGFzIFRva2VuVHlwZVxuICB9XG4gIHJldHVybiBwb3N0Zml4LnBvcCgpIGFzIFRva2VuVHlwZVxufVxuXG5jb25zdCBnZXRHZW9GaWx0ZXJzID0gKFxuICB3a3Q6IHN0cmluZyxcbiAgcHJvcGVydHk6IHN0cmluZyxcbiAgYnVmZmVyPzogc3RyaW5nXG4pOiBGaWx0ZXJDbGFzcyB8IEZpbHRlckJ1aWxkZXJDbGFzcyA9PiB7XG4gIGlmICh3a3Quc3RhcnRzV2l0aCgnR0VPTUVUUllDT0xMRUNUSU9OJykpIHtcbiAgICBjb25zdCBwYXJzZWRXa3QgPSB3a3guR2VvbWV0cnkucGFyc2Uod2t0KVxuICAgIGNvbnN0IGdlb0pzb24gPSBwYXJzZWRXa3QudG9HZW9KU09OKCkgYXMgYW55XG4gICAgY29uc3QgaW5uZXJXa3RzOiBzdHJpbmdbXSA9IGdlb0pzb24uZ2VvbWV0cmllcy5tYXAoKGdlb21ldHJ5OiBhbnkpID0+XG4gICAgICB3a3guR2VvbWV0cnkucGFyc2VHZW9KU09OKGdlb21ldHJ5KS50b1drdCgpXG4gICAgKVxuICAgIHJldHVybiBuZXcgRmlsdGVyQnVpbGRlckNsYXNzKHtcbiAgICAgIHR5cGU6ICdPUicsXG4gICAgICBmaWx0ZXJzOiBpbm5lcldrdHMubWFwKCh3a3QpID0+IGdldEdlb0ZpbHRlcnMod2t0LCBwcm9wZXJ0eSwgYnVmZmVyKSksXG4gICAgfSlcbiAgfSBlbHNlIGlmICh3a3Quc3RhcnRzV2l0aCgnTElORVNUUklORycpKSB7XG4gICAgY29uc3QgbGluZSA9IENRTFV0aWxzLmFycmF5RnJvbUxpbmVzdHJpbmdXa3Qod2t0KVxuICAgIHJldHVybiBnZXRMaW5lc3RyaW5nRmlsdGVyKGxpbmUsIHByb3BlcnR5LCBidWZmZXIpXG4gIH0gZWxzZSBpZiAod2t0LnN0YXJ0c1dpdGgoJ01VTFRJTElORVNUUklORycpKSB7XG4gICAgcmV0dXJuIG5ldyBGaWx0ZXJCdWlsZGVyQ2xhc3Moe1xuICAgICAgdHlwZTogJ09SJyxcbiAgICAgIGZpbHRlcnM6IENRTFV0aWxzLmFycmF5RnJvbU11bHRpbGluZXN0cmluZ1drdCh3a3QpLm1hcChcbiAgICAgICAgKGxpbmU6IG51bWJlcltdW10pID0+IGdldExpbmVzdHJpbmdGaWx0ZXIobGluZSwgcHJvcGVydHksIGJ1ZmZlcilcbiAgICAgICksXG4gICAgfSlcbiAgfSBlbHNlIGlmICh3a3Quc3RhcnRzV2l0aCgnUE9MWUdPTicpKSB7XG4gICAgY29uc3QgcG9seSA9IENRTFV0aWxzLmFycmF5RnJvbVBvbHlnb25Xa3Qod2t0KVxuICAgIHJldHVybiBnZXRQb2x5Z29uRmlsdGVyKHBvbHksIHByb3BlcnR5LCBidWZmZXIpXG4gIH0gZWxzZSBpZiAod2t0LnN0YXJ0c1dpdGgoJ01VTFRJUE9MWUdPTicpKSB7XG4gICAgcmV0dXJuIG5ldyBGaWx0ZXJCdWlsZGVyQ2xhc3Moe1xuICAgICAgdHlwZTogJ09SJyxcbiAgICAgIGZpbHRlcnM6IENRTFV0aWxzLmFycmF5RnJvbVBvbHlnb25Xa3Qod2t0KS5tYXAoKHBvbHk6IG51bWJlcltdW10pID0+XG4gICAgICAgIGdldFBvbHlnb25GaWx0ZXIocG9seSwgcHJvcGVydHksIGJ1ZmZlcilcbiAgICAgICksXG4gICAgfSlcbiAgfSBlbHNlIGlmICh3a3Quc3RhcnRzV2l0aCgnUE9JTlQnKSkge1xuICAgIGNvbnN0IHBvaW50ID0gQ1FMVXRpbHMuYXJyYXlGcm9tUG9pbnRXa3Qod2t0KVswXVxuICAgIHJldHVybiBnZXRQb2ludFJhZGl1c0ZpbHRlcihwb2ludCwgcHJvcGVydHksIGJ1ZmZlcilcbiAgfSBlbHNlIGlmICh3a3Quc3RhcnRzV2l0aCgnTVVMVElQT0lOVCcpKSB7XG4gICAgcmV0dXJuIG5ldyBGaWx0ZXJCdWlsZGVyQ2xhc3Moe1xuICAgICAgdHlwZTogJ09SJyxcbiAgICAgIGZpbHRlcnM6IENRTFV0aWxzLmFycmF5RnJvbVBvaW50V2t0KHdrdCkubWFwKChwb2ludDogW251bWJlciwgbnVtYmVyXSkgPT5cbiAgICAgICAgZ2V0UG9pbnRSYWRpdXNGaWx0ZXIocG9pbnQsIHByb3BlcnR5LCBidWZmZXIpXG4gICAgICApLFxuICAgIH0pXG4gIH1cbiAgdGhyb3cgbmV3IEVycm9yKCdVbmtub3duIHNwYXRpYWwgdHlwZSBlbmNvdW50ZXJlZCcpXG59XG5cbmZ1bmN0aW9uIGJ1aWxkVHJlZShwb3N0Zml4OiBBcnJheTxUb2tlblR5cGU+KTogYW55IHtcbiAgbGV0IHZhbHVlLFxuICAgIHByb3BlcnR5LFxuICAgIHRvayA9IGdldE5leHRUb2tlbihwb3N0Zml4KVxuICBjb25zdCB0b2tlblR5cGUgPSB0b2sudHlwZVxuICBzd2l0Y2ggKHRva2VuVHlwZSkge1xuICAgIGNhc2UgJ0xPR0lDQUwnOlxuICAgICAgY29uc3QgcmhzID0gYnVpbGRUcmVlKHBvc3RmaXgpLFxuICAgICAgICBsaHMgPSBidWlsZFRyZWUocG9zdGZpeClcbiAgICAgIHJldHVybiBuZXcgRmlsdGVyQnVpbGRlckNsYXNzKHtcbiAgICAgICAgZmlsdGVyczogW2xocywgcmhzXSxcbiAgICAgICAgdHlwZTogdG9rLnRleHQudG9VcHBlckNhc2UoKSBhcyBGaWx0ZXJCdWlsZGVyQ2xhc3NbJ3R5cGUnXSxcbiAgICAgIH0pXG4gICAgY2FzZSAnTk9UJzpcbiAgICAgIGNvbnN0IHBlZWtUb2tlbiA9IHBvc3RmaXhbcG9zdGZpeC5sZW5ndGggLSAxXSBhcyBUb2tlblR5cGVcbiAgICAgIGlmIChwZWVrVG9rZW4udHlwZSA9PT0gJ0xPR0lDQUwnKSB7XG4gICAgICAgIHJldHVybiBuZXcgRmlsdGVyQnVpbGRlckNsYXNzKHtcbiAgICAgICAgICAuLi5idWlsZFRyZWUocG9zdGZpeCksXG4gICAgICAgICAgbmVnYXRlZDogdHJ1ZSxcbiAgICAgICAgfSlcbiAgICAgIH0gZWxzZSBpZiAocGVla1Rva2VuLnR5cGUgPT09ICdOT1QnKSB7XG4gICAgICAgIHJldHVybiBuZXcgRmlsdGVyQnVpbGRlckNsYXNzKHtcbiAgICAgICAgICBmaWx0ZXJzOiBbYnVpbGRUcmVlKHBvc3RmaXgpXSxcbiAgICAgICAgICB0eXBlOiAnQU5EJyxcbiAgICAgICAgICBuZWdhdGVkOiB0cnVlLFxuICAgICAgICB9KVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIG5ldyBGaWx0ZXJDbGFzcyh7XG4gICAgICAgICAgLi4uYnVpbGRUcmVlKHBvc3RmaXgpLFxuICAgICAgICAgIG5lZ2F0ZWQ6IHRydWUsXG4gICAgICAgIH0pXG4gICAgICB9XG4gICAgY2FzZSAnQkVUV0VFTic6IC8vIHdvcmtzXG4gICAgICBsZXQgbWluLCBtYXhcbiAgICAgIHBvc3RmaXgucG9wKCkgLy8gdW5uZWVkZWQgQU5EIHRva2VuIGhlcmVcbiAgICAgIG1heCA9IGJ1aWxkVHJlZShwb3N0Zml4KVxuICAgICAgbWluID0gYnVpbGRUcmVlKHBvc3RmaXgpXG4gICAgICBwcm9wZXJ0eSA9IGJ1aWxkVHJlZShwb3N0Zml4KVxuICAgICAgcmV0dXJuIG5ldyBGaWx0ZXJDbGFzcyh7XG4gICAgICAgIHByb3BlcnR5LFxuICAgICAgICB2YWx1ZToge1xuICAgICAgICAgIHN0YXJ0OiBtaW4sXG4gICAgICAgICAgZW5kOiBtYXgsXG4gICAgICAgIH0gYXMgVmFsdWVUeXBlc1snYmV0d2VlbiddLFxuICAgICAgICB0eXBlOiB0b2tlblR5cGUgYXMgRmlsdGVyQ2xhc3NbJ3R5cGUnXSxcbiAgICAgIH0pXG4gICAgY2FzZSAnQkVGT1JFJzogLy8gd29ya3NcbiAgICBjYXNlICdBRlRFUic6IC8vIHdvcmtzXG4gICAgICB2YWx1ZSA9IGJ1aWxkVHJlZShwb3N0Zml4KVxuICAgICAgcHJvcGVydHkgPSBidWlsZFRyZWUocG9zdGZpeClcbiAgICAgIHJldHVybiBuZXcgRmlsdGVyQ2xhc3Moe1xuICAgICAgICBwcm9wZXJ0eSxcbiAgICAgICAgdmFsdWU6IHZhbHVlIGFzIFZhbHVlVHlwZXNbJ2RhdGUnXSxcbiAgICAgICAgdHlwZTogdG9rLnRleHQudG9VcHBlckNhc2UoKSBhcyBGaWx0ZXJDbGFzc1sndHlwZSddLFxuICAgICAgfSlcbiAgICBjYXNlICdEVVJJTkcnOiAvLyB0ZWNobmljYWxseSBiZXR3ZWVuIGZvciBkYXRlcywgd29ya3NcbiAgICAgIGNvbnN0IGRhdGVzID0gYnVpbGRUcmVlKHBvc3RmaXgpLnNwbGl0KCcvJylcbiAgICAgIHByb3BlcnR5ID0gYnVpbGRUcmVlKHBvc3RmaXgpXG4gICAgICByZXR1cm4gbmV3IEZpbHRlckNsYXNzKHtcbiAgICAgICAgcHJvcGVydHksXG4gICAgICAgIHZhbHVlOiB7XG4gICAgICAgICAgc3RhcnQ6IGRhdGVzWzBdLFxuICAgICAgICAgIGVuZDogZGF0ZXNbMV0sXG4gICAgICAgIH0gYXMgVmFsdWVUeXBlc1snZHVyaW5nJ10sXG4gICAgICAgIHR5cGU6IHRvay50ZXh0LnRvVXBwZXJDYXNlKCkgYXMgRmlsdGVyQ2xhc3NbJ3R5cGUnXSxcbiAgICAgIH0pXG4gICAgY2FzZSAnQ09NUEFSSVNPTic6IC8vIHdvcmtzXG4gICAgICB2YWx1ZSA9IGJ1aWxkVHJlZShwb3N0Zml4KSBhcyBWYWx1ZVR5cGVzWydpbnRlZ2VyJ11cbiAgICAgIHByb3BlcnR5ID0gYnVpbGRUcmVlKHBvc3RmaXgpXG4gICAgICByZXR1cm4gbmV3IEZpbHRlckNsYXNzKHtcbiAgICAgICAgcHJvcGVydHksXG4gICAgICAgIHZhbHVlLFxuICAgICAgICB0eXBlOiB0b2sudGV4dC50b1VwcGVyQ2FzZSgpIGFzIEZpbHRlckNsYXNzWyd0eXBlJ10sXG4gICAgICB9KVxuICAgIGNhc2UgJ0lTX05VTEwnOiAvLyB3b3Jrc1xuICAgICAgcHJvcGVydHkgPSBidWlsZFRyZWUocG9zdGZpeClcbiAgICAgIHJldHVybiBuZXcgRmlsdGVyQ2xhc3Moe1xuICAgICAgICBwcm9wZXJ0eSxcbiAgICAgICAgdHlwZTogdG9rLnRleHQudG9VcHBlckNhc2UoKSBhcyBGaWx0ZXJDbGFzc1sndHlwZSddLFxuICAgICAgfSlcbiAgICBjYXNlICdWQUxVRSc6IC8vd29ya3NcbiAgICAgIGNvbnN0IG1hdGNoID0gdG9rLnRleHQubWF0Y2goL14nKC4qKSckLylcbiAgICAgIGlmIChtYXRjaCkge1xuICAgICAgICBpZiAodW53cmFwKHBvc3RmaXhbMF0udGV4dCkgPT09ICdpZCcpIHtcbiAgICAgICAgICAvLyBkb24ndCBlc2NhcGUgaWRzXG4gICAgICAgICAgcmV0dXJuIG1hdGNoWzFdLnJlcGxhY2UoLycnL2csIFwiJ1wiKVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJldHVybiB0cmFuc2xhdGVDcWxUb1VzZXJxbChtYXRjaFsxXS5yZXBsYWNlKC8nJy9nLCBcIidcIikpXG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJldHVybiBOdW1iZXIodG9rLnRleHQpXG4gICAgICB9XG4gICAgY2FzZSAnQk9PTEVBTic6IC8vIHdvcmtzXG4gICAgICBzd2l0Y2ggKHRvay50ZXh0LnRvVXBwZXJDYXNlKCkpIHtcbiAgICAgICAgY2FzZSAnVFJVRSc6XG4gICAgICAgICAgcmV0dXJuIHRydWVcbiAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICByZXR1cm4gZmFsc2VcbiAgICAgIH1cbiAgICBjYXNlICdTUEFUSUFMJzogLy8gd29ya2luZ1xuICAgICAgLy8gbmV4dCB0b2tlbiB0ZWxscyB1cyB3aGV0aGVyIHRoaXMgaXMgRFdJVEhJTiBvciBJTlRFUlNFQ1RTXG4gICAgICBzd2l0Y2ggKHRvay50ZXh0KSB7XG4gICAgICAgIGNhc2UgJ0lOVEVSU0VDVFMnOiB7XG4gICAgICAgICAgLy8gdGhpbmdzIHdpdGhvdXQgYnVmZmVycywgY291bGQgYmUgcG9seSBvciBsaW5lXG4gICAgICAgICAgY29uc3QgdmFsdWVUb2tlbiA9IHBvc3RmaXgucG9wKCkgYXMgVG9rZW5UeXBlXG4gICAgICAgICAgY29uc3QgcHJvcGVydHlUb2tlbiA9IHBvc3RmaXgucG9wKCkgYXMgVG9rZW5UeXBlXG4gICAgICAgICAgcmV0dXJuIGdldEdlb0ZpbHRlcnModmFsdWVUb2tlbi50ZXh0LCBwcm9wZXJ0eVRva2VuLnRleHQsIHVuZGVmaW5lZClcbiAgICAgICAgfVxuICAgICAgICBjYXNlICdEV0lUSElOJzoge1xuICAgICAgICAgIC8vIHRoaW5ncyB3aXRoIGJ1ZmZlcnMsIGNvdWxkIGJlIHBvbHksIGxpbmUgb3IgcG9pbnRcbiAgICAgICAgICBjb25zdCBidWZmZXJUb2tlbiA9IHBvc3RmaXgucG9wKCkgYXMgVG9rZW5UeXBlXG4gICAgICAgICAgY29uc3QgdmFsdWVUb2tlbiA9IHBvc3RmaXgucG9wKCkgYXMgVG9rZW5UeXBlXG4gICAgICAgICAgY29uc3QgcHJvcGVydHlUb2tlbiA9IHBvc3RmaXgucG9wKCkgYXMgVG9rZW5UeXBlXG4gICAgICAgICAgcmV0dXJuIGdldEdlb0ZpbHRlcnMoXG4gICAgICAgICAgICB2YWx1ZVRva2VuLnRleHQsXG4gICAgICAgICAgICBwcm9wZXJ0eVRva2VuLnRleHQsXG4gICAgICAgICAgICBidWZmZXJUb2tlbi50ZXh0XG4gICAgICAgICAgKVxuICAgICAgICB9XG4gICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdVbmtub3duIHNwYXRpYWwgdHlwZSBlbmNvdW50ZXJlZCcpXG4gICAgICB9XG4gICAgY2FzZSAnR0VPTUVUUlknOlxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgdHlwZTogdG9rZW5UeXBlLFxuICAgICAgICB2YWx1ZTogdG9rLnRleHQsXG4gICAgICB9XG4gICAgY2FzZSAnUkVMQVRJVkUnOlxuICAgICAgcmV0dXJuIG5ldyBGaWx0ZXJDbGFzcyh7XG4gICAgICAgIHR5cGU6ICdSRUxBVElWRScsXG4gICAgICAgIHZhbHVlOiBkZXNlcmlhbGl6ZS5kYXRlUmVsYXRpdmUodG9rLnRleHQpLFxuICAgICAgICBwcm9wZXJ0eTogKHBvc3RmaXgucG9wKCkgYXMgVG9rZW5UeXBlKS50ZXh0LFxuICAgICAgfSlcbiAgICBjYXNlICdGSUxURVJfRlVOQ1RJT04nOiAvLyB3b3JraW5nXG4gICAgICBjb25zdCBmaWx0ZXJGdW5jdGlvbk5hbWUgPSB0b2sudGV4dC5zbGljZSgwLCAtMSkgLy8gcmVtb3ZlIHRyYWlsaW5nICcoJ1xuICAgICAgY29uc3QgcGFyYW1Db3VudCA9XG4gICAgICAgIGZpbHRlckZ1bmN0aW9uUGFyYW1Db3VudFtmaWx0ZXJGdW5jdGlvbk5hbWUgYXMgRmlsdGVyRnVuY3Rpb25OYW1lc11cbiAgICAgIGlmIChwYXJhbUNvdW50ID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdVbnN1cHBvcnRlZCBmaWx0ZXIgZnVuY3Rpb246ICcgKyBmaWx0ZXJGdW5jdGlvbk5hbWUpXG4gICAgICB9XG4gICAgICBjb25zdCBwYXJhbXMgPSBBcnJheS5hcHBseShudWxsLCBBcnJheShwYXJhbUNvdW50KSlcbiAgICAgICAgLm1hcCgoKSA9PiBidWlsZFRyZWUocG9zdGZpeCkpXG4gICAgICAgIC5yZXZlcnNlKClcbiAgICAgIHN3aXRjaCAoZmlsdGVyRnVuY3Rpb25OYW1lKSB7XG4gICAgICAgIGNhc2UgJ3Byb3hpbWl0eSc6XG4gICAgICAgICAgY29uc3QgcHJveGltaXR5U3RyaW5ncyA9IHBhcmFtc1syXSBhcyBzdHJpbmdcbiAgICAgICAgICByZXR1cm4gbmV3IEZpbHRlckNsYXNzKHtcbiAgICAgICAgICAgIHR5cGU6ICdGSUxURVIgRlVOQ1RJT04gcHJveGltaXR5JyxcbiAgICAgICAgICAgIHByb3BlcnR5OiBwYXJhbXNbMF0sXG4gICAgICAgICAgICB2YWx1ZToge1xuICAgICAgICAgICAgICBmaXJzdDogcHJveGltaXR5U3RyaW5ncy5zcGxpdCgnICcpWzBdLFxuICAgICAgICAgICAgICBzZWNvbmQ6IHByb3hpbWl0eVN0cmluZ3Muc3BsaXQoJyAnKVsxXSxcbiAgICAgICAgICAgICAgZGlzdGFuY2U6IHBhcmFtc1sxXSxcbiAgICAgICAgICAgIH0gYXMgVmFsdWVUeXBlc1sncHJveGltaXR5J10sXG4gICAgICAgICAgfSlcbiAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1Vua25vd24gZmlsdGVyIGZ1bmN0aW9uJylcbiAgICAgIH1cbiAgICBjYXNlICdUSU1FX1BFUklPRCc6XG4gICAgICByZXR1cm4gdG9rLnRleHRcbiAgICBkZWZhdWx0OlxuICAgICAgcmV0dXJuIHRvay50ZXh0XG4gIH1cbn1cblxuZnVuY3Rpb24gYnVpbGRBc3QodG9rZW5zOiBUb2tlblR5cGVbXSkge1xuICBjb25zdCBvcGVyYXRvclN0YWNrID0gW10gYXMgQXJyYXk8VG9rZW5UeXBlPixcbiAgICBwb3N0Zml4ID0gW10gYXMgQXJyYXk8VG9rZW5UeXBlPlxuXG4gIHdoaWxlICh0b2tlbnMubGVuZ3RoKSB7XG4gICAgY29uc3QgdG9rID0gdG9rZW5zLnNoaWZ0KCkgYXMgVG9rZW5UeXBlXG4gICAgc3dpdGNoICh0b2sudHlwZSkge1xuICAgICAgY2FzZSAnUFJPUEVSVFknOlxuICAgICAgICB0b2sudGV4dCA9IHVud3JhcCh0b2sudGV4dClcbiAgICAgIGNhc2UgJ0dFT01FVFJZJzpcbiAgICAgIGNhc2UgJ1ZBTFVFJzpcbiAgICAgIGNhc2UgJ1RJTUUnOlxuICAgICAgY2FzZSAnVElNRV9QRVJJT0QnOlxuICAgICAgY2FzZSAnUkVMQVRJVkUnOlxuICAgICAgY2FzZSAnQk9PTEVBTic6XG4gICAgICAgIHBvc3RmaXgucHVzaCh0b2spXG4gICAgICAgIGJyZWFrXG4gICAgICBjYXNlICdDT01QQVJJU09OJzpcbiAgICAgIGNhc2UgJ0JFVFdFRU4nOlxuICAgICAgY2FzZSAnSVNfTlVMTCc6XG4gICAgICBjYXNlICdMT0dJQ0FMJzpcbiAgICAgIGNhc2UgJ0JFRk9SRSc6XG4gICAgICBjYXNlICdBRlRFUic6XG4gICAgICBjYXNlICdEVVJJTkcnOlxuICAgICAgICBjb25zdCBwID0gcHJlY2VkZW5jZVt0b2sudHlwZSBhcyBQcmVjZW5kZW5jZVR5cGVdXG5cbiAgICAgICAgd2hpbGUgKFxuICAgICAgICAgIG9wZXJhdG9yU3RhY2subGVuZ3RoID4gMCAmJlxuICAgICAgICAgIHByZWNlZGVuY2VbXG4gICAgICAgICAgICBvcGVyYXRvclN0YWNrW29wZXJhdG9yU3RhY2subGVuZ3RoIC0gMV0udHlwZSBhcyBQcmVjZW5kZW5jZVR5cGVcbiAgICAgICAgICBdIDw9IHBcbiAgICAgICAgKSB7XG4gICAgICAgICAgcG9zdGZpeC5wdXNoKG9wZXJhdG9yU3RhY2sucG9wKCkgYXMgVG9rZW5UeXBlKVxuICAgICAgICB9XG5cbiAgICAgICAgb3BlcmF0b3JTdGFjay5wdXNoKHRvaylcbiAgICAgICAgYnJlYWtcbiAgICAgIGNhc2UgJ1NQQVRJQUwnOlxuICAgICAgY2FzZSAnTk9UJzpcbiAgICAgIGNhc2UgJ0xQQVJFTic6XG4gICAgICAgIG9wZXJhdG9yU3RhY2sucHVzaCh0b2spXG4gICAgICAgIGJyZWFrXG4gICAgICBjYXNlICdGSUxURVJfRlVOQ1RJT04nOlxuICAgICAgICBvcGVyYXRvclN0YWNrLnB1c2godG9rKVxuICAgICAgICAvLyBpbnNlcnQgYSAnKCcgbWFudWFsbHkgYmVjYXVzZSB3ZSBsb3N0IHRoZSBvcmlnaW5hbCBMUEFSRU4gbWF0Y2hpbmcgdGhlIEZJTFRFUl9GVU5DVElPTiByZWdleFxuICAgICAgICBvcGVyYXRvclN0YWNrLnB1c2goeyB0eXBlOiAnTFBBUkVOJyB9IGFzIFRva2VuVHlwZSlcbiAgICAgICAgYnJlYWtcbiAgICAgIGNhc2UgJ1JQQVJFTic6XG4gICAgICAgIHdoaWxlIChcbiAgICAgICAgICBvcGVyYXRvclN0YWNrLmxlbmd0aCA+IDAgJiZcbiAgICAgICAgICBvcGVyYXRvclN0YWNrW29wZXJhdG9yU3RhY2subGVuZ3RoIC0gMV0udHlwZSAhPT0gJ0xQQVJFTidcbiAgICAgICAgKSB7XG4gICAgICAgICAgcG9zdGZpeC5wdXNoKG9wZXJhdG9yU3RhY2sucG9wKCkgYXMgVG9rZW5UeXBlKVxuICAgICAgICB9XG4gICAgICAgIG9wZXJhdG9yU3RhY2sucG9wKCkgLy8gdG9zcyBvdXQgdGhlIExQQVJFTlxuXG4gICAgICAgIC8vIGlmIHRoaXMgcmlnaHQgcGFyZW50aGVzaXMgZW5kcyBhIGZ1bmN0aW9uIGFyZ3VtZW50IGxpc3QgKGl0J3Mgbm90IGZvciBhIGxvZ2ljYWwgZ3JvdXBpbmcpLFxuICAgICAgICAvLyBpdCdzIG5vdyB0aW1lIHRvIGFkZCB0aGF0IGZ1bmN0aW9uIHRvIHRoZSBwb3N0Zml4LW9yZGVyZWQgbGlzdFxuICAgICAgICBjb25zdCBsYXN0T3BlcmF0b3JUeXBlID1cbiAgICAgICAgICBvcGVyYXRvclN0YWNrLmxlbmd0aCA+IDAgJiZcbiAgICAgICAgICBvcGVyYXRvclN0YWNrW29wZXJhdG9yU3RhY2subGVuZ3RoIC0gMV0udHlwZVxuICAgICAgICBpZiAoXG4gICAgICAgICAgbGFzdE9wZXJhdG9yVHlwZSA9PT0gJ1NQQVRJQUwnIHx8XG4gICAgICAgICAgbGFzdE9wZXJhdG9yVHlwZSA9PT0gJ0ZJTFRFUl9GVU5DVElPTidcbiAgICAgICAgKSB7XG4gICAgICAgICAgcG9zdGZpeC5wdXNoKG9wZXJhdG9yU3RhY2sucG9wKCkgYXMgVG9rZW5UeXBlKVxuICAgICAgICB9XG4gICAgICAgIGJyZWFrXG4gICAgICBjYXNlICdDT01NQSc6XG4gICAgICBjYXNlICdFTkQnOlxuICAgICAgY2FzZSAnVU5JVFMnOlxuICAgICAgICBicmVha1xuICAgICAgZGVmYXVsdDpcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdVbmtub3duIHRva2VuIHR5cGUgJyArIHRvay50eXBlKVxuICAgIH1cbiAgfVxuXG4gIHdoaWxlIChvcGVyYXRvclN0YWNrLmxlbmd0aCA+IDApIHtcbiAgICBwb3N0Zml4LnB1c2gob3BlcmF0b3JTdGFjay5wb3AoKSBhcyBUb2tlblR5cGUpXG4gIH1cblxuICBjb25zdCByZXN1bHQgPSBidWlsZFRyZWUocG9zdGZpeClcbiAgaWYgKHBvc3RmaXgubGVuZ3RoID4gMCkge1xuICAgIGxldCBtc2cgPSAnUmVtYWluaW5nIHRva2VucyBhZnRlciBidWlsZGluZyBBU1Q6IFxcbidcbiAgICBmb3IgKGxldCBpID0gcG9zdGZpeC5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuICAgICAgbXNnICs9IHBvc3RmaXhbaV0udHlwZSArICc6ICcgKyBwb3N0Zml4W2ldLnRleHQgKyAnXFxuJ1xuICAgIH1cbiAgICB0aHJvdyBuZXcgRXJyb3IobXNnKVxuICB9XG5cbiAgcmV0dXJuIHJlc3VsdFxufVxuXG5mdW5jdGlvbiB3cmFwKHByb3BlcnR5OiBzdHJpbmcpOiBzdHJpbmcge1xuICBsZXQgd3JhcHBlZCA9IHByb3BlcnR5XG4gIGlmICghd3JhcHBlZC5zdGFydHNXaXRoKCdcIicpKSB7XG4gICAgd3JhcHBlZCA9ICdcIicgKyB3cmFwcGVkXG4gIH1cbiAgaWYgKCF3cmFwcGVkLmVuZHNXaXRoKCdcIicpKSB7XG4gICAgd3JhcHBlZCA9IHdyYXBwZWQgKyAnXCInXG4gIH1cbiAgcmV0dXJuIHdyYXBwZWRcbn1cblxuZnVuY3Rpb24gdW53cmFwKHByb3BlcnR5OiBzdHJpbmcpOiBzdHJpbmcge1xuICAvLyBSZW1vdmUgc2luZ2xlIGFuZCBkb3VibGUgcXVvdGVzIGlmIHRoZXkgZXhpc3QgaW4gcHJvcGVydHkgbmFtZVxuICByZXR1cm4gcHJvcGVydHkucmVwbGFjZSgvXid8JyQvZywgJycpLnJlcGxhY2UoL15cInxcIiQvZywgJycpXG59XG5cbi8vIHJlYWxseSBjb3VsZCB1c2Ugc29tZSByZWZhY3RvcmluZyB0byBlbmFibGUgYmV0dGVyIHR5cGluZywgcmlnaHQgbm93IGl0J3MgcmVjdXJzaXZlIGFuZCBjYWxscyBpdHNlbGYgd2l0aCBzbyBtYW55IGRpZmZlcmVudCB0eXBlcyAvIHJldHVybiB0eXBlc1xuZnVuY3Rpb24gd3JpdGUoZmlsdGVyOiBhbnkpOiBhbnkge1xuICBzd2l0Y2ggKGZpbHRlci50eXBlKSB7XG4gICAgLy8gc3BhdGlhbENsYXNzXG4gICAgY2FzZSAnQkJPWCc6XG4gICAgICBjb25zdCB4bWluID0gZmlsdGVyLnZhbHVlWzBdLFxuICAgICAgICB5bWluID0gZmlsdGVyLnZhbHVlWzFdLFxuICAgICAgICB4bWF4ID0gZmlsdGVyLnZhbHVlWzJdLFxuICAgICAgICB5bWF4ID0gZmlsdGVyLnZhbHVlWzNdXG4gICAgICByZXR1cm4gKFxuICAgICAgICAnQkJPWCgnICtcbiAgICAgICAgd3JhcChmaWx0ZXIucHJvcGVydHkpICtcbiAgICAgICAgJywnICtcbiAgICAgICAgeG1pbiArXG4gICAgICAgICcsJyArXG4gICAgICAgIHltaW4gK1xuICAgICAgICAnLCcgK1xuICAgICAgICB4bWF4ICtcbiAgICAgICAgJywnICtcbiAgICAgICAgeW1heCArXG4gICAgICAgICcpJ1xuICAgICAgKVxuICAgIC8vIHZlcmlmaWVkIGxpbmUsIHBvbHlnb24sIHBvaW50IHJhZGl1c1xuICAgIGNhc2UgJ0RXSVRISU4nOlxuICAgICAgcmV0dXJuIGBEV0lUSElOKCR7d3JhcChmaWx0ZXIucHJvcGVydHkpfSwgJHtmaWx0ZXIudmFsdWV9LCAke1xuICAgICAgICBmaWx0ZXIuZGlzdGFuY2VcbiAgICAgIH0sIG1ldGVycylgXG4gICAgLy8gdW51c2VkIGF0IHRoZSBtb21lbnRcbiAgICBjYXNlICdXSVRISU4nOlxuICAgICAgcmV0dXJuIChcbiAgICAgICAgJ1dJVEhJTignICsgd3JhcChmaWx0ZXIucHJvcGVydHkpICsgJywgJyArIHdyaXRlKGZpbHRlci52YWx1ZSkgKyAnKSdcbiAgICAgIClcbiAgICAvLyB2ZXJpZmllZCBiYm94XG4gICAgY2FzZSAnSU5URVJTRUNUUyc6XG4gICAgICByZXR1cm4gJ0lOVEVSU0VDVFMoJyArIHdyYXAoZmlsdGVyLnByb3BlcnR5KSArICcsICcgKyBmaWx0ZXIudmFsdWUgKyAnKSdcbiAgICAvLyB1bnVzZWQgYXQgdGhlIG1vbWVudFxuICAgIGNhc2UgJ0NPTlRBSU5TJzpcbiAgICAgIHJldHVybiAoXG4gICAgICAgICdDT05UQUlOUygnICsgd3JhcChmaWx0ZXIucHJvcGVydHkpICsgJywgJyArIHdyaXRlKGZpbHRlci52YWx1ZSkgKyAnKSdcbiAgICAgIClcbiAgICAvLyBhbGwgXCJnZW9cIiBmaWx0ZXJzIHBhc3MgdGhyb3VnaCB0aGlzIGZpcnN0LCB3aGljaCBzZXJpYWxpemVzIHRoZW0gaW50byBhIGZvcm0gdGhhdCBjcWwgdW5kZXJzdGFuZHNcbiAgICAvLyB0aGlzIGlzIG9ubHkgZG9uZSBoZXJlIG9uIHRoZSBmbHkgYmVjYXVzZSB0aGUgdHJhbnNmb3JtYXRpb24gaW52b2x2ZXMgYSBsb3NzIG9mIGluZm9ybWF0aW9uXG4gICAgLy8gKHN1Y2ggYXMgdGhlIHVuaXRzIFttZXRlcnMgb3IgbWlsZXM/XSBhbmQgY29vcmRpbmF0ZSBzeXN0ZW0gW2RtcyBvciBtZ3JzP10pXG4gICAgY2FzZSAnR0VPTUVUUlknOlxuICAgICAgcmV0dXJuIHdyaXRlKHNlcmlhbGl6ZS5sb2NhdGlvbihmaWx0ZXIucHJvcGVydHksIGZpbHRlci52YWx1ZSkpXG4gICAgLy8gbG9naWNhbENsYXNzXG4gICAgY2FzZSAnQU5EJzpcbiAgICBjYXNlICdPUic6XG4gICAgICBsZXQgcmVzID0gJygnXG4gICAgICBsZXQgZmlyc3QgPSB0cnVlXG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGZpbHRlci5maWx0ZXJzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGNvbnN0IHdyaXR0ZW5GaWx0ZXIgPSB3cml0ZShmaWx0ZXIuZmlsdGVyc1tpXSlcbiAgICAgICAgaWYgKHdyaXR0ZW5GaWx0ZXIpIHtcbiAgICAgICAgICBpZiAoZmlyc3QpIHtcbiAgICAgICAgICAgIGZpcnN0ID0gZmFsc2VcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcmVzICs9ICcpICcgKyBmaWx0ZXIudHlwZSArICcgKCdcbiAgICAgICAgICB9XG4gICAgICAgICAgcmVzICs9IHdyaXR0ZW5GaWx0ZXJcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIHJlcyArICcpJ1xuICAgIGNhc2UgJ05PVCc6XG4gICAgICAvLyBUT0RPOiBkZWFsIHdpdGggcHJlY2VkZW5jZSBvZiBsb2dpY2FsIG9wZXJhdG9ycyB0b1xuICAgICAgLy8gYXZvaWQgZXh0cmEgcGFyZW50aGVzZXMgKG5vdCB1cmdlbnQpXG4gICAgICByZXR1cm4gJ05PVCAoJyArIHdyaXRlKGZpbHRlci5maWx0ZXJzWzBdKSArICcpJ1xuICAgIC8vIGNvbXBhcmlzb25DbGFzc1xuICAgIGNhc2UgJ0lTIE5VTEwnOlxuICAgICAgcmV0dXJuIGAoXCIke2ZpbHRlci5wcm9wZXJ0eX1cIiAke2ZpbHRlci50eXBlfSlgXG4gICAgY2FzZSAnQkVUV0VFTic6XG4gICAgICByZXR1cm4gKFxuICAgICAgICB3cmFwKGZpbHRlci5wcm9wZXJ0eSkgK1xuICAgICAgICAnIEJFVFdFRU4gJyArXG4gICAgICAgIHdyaXRlKE1hdGgubWluKGZpbHRlci52YWx1ZS5zdGFydCwgZmlsdGVyLnZhbHVlLmVuZCkpICtcbiAgICAgICAgJyBBTkQgJyArXG4gICAgICAgIHdyaXRlKE1hdGgubWF4KGZpbHRlci52YWx1ZS5zdGFydCwgZmlsdGVyLnZhbHVlLmVuZCkpXG4gICAgICApXG4gICAgY2FzZSAnPSc6XG4gICAgY2FzZSAnPD4nOlxuICAgIGNhc2UgJzwnOlxuICAgIGNhc2UgJzw9JzpcbiAgICBjYXNlICc+JzpcbiAgICBjYXNlICc+PSc6XG4gICAgY2FzZSAnTElLRSc6XG4gICAgY2FzZSAnSUxJS0UnOlxuICAgICAgbGV0IHByb3BlcnR5ID1cbiAgICAgICAgdHlwZW9mIGZpbHRlci5wcm9wZXJ0eSA9PT0gJ29iamVjdCdcbiAgICAgICAgICA/IHdyaXRlKGZpbHRlci5wcm9wZXJ0eSlcbiAgICAgICAgICA6IHdyYXAodW53cmFwKGZpbHRlci5wcm9wZXJ0eSkpIC8vIHVud3JhcCBmaXJzdCwgYmVjYXVzZSB0ZWNobmljYWxseSBvbmx5IFwiXCIgaXMgc3VwcG9ydGVkIChzbyBzd2FwICcnIGZvciBcIlwiKVxuXG4gICAgICBpZiAoZmlsdGVyLnZhbHVlID09PSBudWxsKSB7XG4gICAgICAgIHJldHVybiBgJHtwcm9wZXJ0eX0gJHtmaWx0ZXIudHlwZX1gXG4gICAgICB9XG5cbiAgICAgIHJldHVybiBgJHtwcm9wZXJ0eX0gJHtmaWx0ZXIudHlwZX0gJHtcbiAgICAgICAgdW53cmFwKGZpbHRlci5wcm9wZXJ0eSkgPT09ICdpZCdcbiAgICAgICAgICA/IGAnJHtmaWx0ZXIudmFsdWV9J2BcbiAgICAgICAgICA6IHdyaXRlKGZpbHRlci52YWx1ZSlcbiAgICAgIH1gIC8vIGRvbid0IGVzY2FwZSBpZHNcbiAgICAvLyB0ZW1wb3JhbENsYXNzXG4gICAgY2FzZSAnUkVMQVRJVkUnOlxuICAgICAgLy8gd2VpcmQgdGhpbmcgSSBub3RpY2VkIGlzIHlvdSBoYXZlIHRvIHdyYXAgdGhlIHZhbHVlIGluIHNpbmdsZSBxdW90ZXMsIGRvdWJsZSBxdW90ZXMgZG9uJ3Qgd29ya1xuICAgICAgcmV0dXJuIGAke3dyYXAoZmlsdGVyLnByb3BlcnR5KX0gPSAnJHtzZXJpYWxpemUuZGF0ZVJlbGF0aXZlKFxuICAgICAgICBmaWx0ZXIudmFsdWVcbiAgICAgICl9J2BcbiAgICBjYXNlICdBUk9VTkQnOlxuICAgICAgcmV0dXJuIGAke3dyYXAoZmlsdGVyLnByb3BlcnR5KX0gJHtzZXJpYWxpemUuZGF0ZUFyb3VuZChmaWx0ZXIudmFsdWUpfWBcbiAgICBjYXNlICdCRUZPUkUnOlxuICAgIGNhc2UgJ0FGVEVSJzpcbiAgICAgIHJldHVybiAoXG4gICAgICAgIHdyYXAoZmlsdGVyLnByb3BlcnR5KSArXG4gICAgICAgICcgJyArXG4gICAgICAgIGZpbHRlci50eXBlICtcbiAgICAgICAgJyAnICtcbiAgICAgICAgKGZpbHRlci52YWx1ZSA/IGZpbHRlci52YWx1ZS50b1N0cmluZyhkYXRlVGltZUZvcm1hdCkgOiBcIicnXCIpXG4gICAgICApXG4gICAgY2FzZSAnRFVSSU5HJzpcbiAgICAgIHJldHVybiBgJHt3cmFwKGZpbHRlci5wcm9wZXJ0eSl9ICR7ZmlsdGVyLnR5cGV9ICR7ZmlsdGVyLnZhbHVlLnN0YXJ0fS8ke1xuICAgICAgICBmaWx0ZXIudmFsdWUuZW5kXG4gICAgICB9YFxuICAgIC8vIGZpbHRlckZ1bmN0aW9uQ2xhc3NcbiAgICBjYXNlICdGSUxURVIgRlVOQ1RJT04gcHJveGltaXR5JzpcbiAgICAgIC8vIG5vdCBzdXJlIHdoeSB3ZSBuZWVkIHRoZSA9IHRydWUgcGFydCBidXQgd2l0aG91dCBpdCB0aGUgYmFja2VuZCBmYWlscyB0byBwYXJzZVxuICAgICAgcmV0dXJuIGBwcm94aW1pdHkoJHt3cml0ZShmaWx0ZXIucHJvcGVydHkpfSwke3dyaXRlKFxuICAgICAgICBmaWx0ZXIudmFsdWUuZGlzdGFuY2VcbiAgICAgICl9LCR7d3JpdGUoYCR7ZmlsdGVyLnZhbHVlLmZpcnN0fSAke2ZpbHRlci52YWx1ZS5zZWNvbmR9YCl9KSA9IHRydWVgXG4gICAgICBicmVha1xuICAgIGNhc2UgJ0JPT0xFQU5fVEVYVF9TRUFSQ0gnOlxuICAgICAgY29uc3QgYm9vbGVhblRleHRTZWFyY2hGaWx0ZXIgPSBmaWx0ZXIudmFsdWUgYXMgQm9vbGVhblRleHRUeXBlXG4gICAgICBpZiAoYm9vbGVhblRleHRTZWFyY2hGaWx0ZXIuZXJyb3IpIHtcbiAgICAgICAgcmV0dXJuXG4gICAgICB9IGVsc2UgaWYgKGJvb2xlYW5UZXh0U2VhcmNoRmlsdGVyLmNxbCA9PT0gJycpIHtcbiAgICAgICAgcmV0dXJuIFwiKGFueVRleHQgSUxJS0UgJyonKVwiXG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXR1cm4gYm9vbGVhblRleHRTZWFyY2hGaWx0ZXIuY3FsXG4gICAgICB9XG4gICAgICBicmVha1xuICAgIGNhc2UgdW5kZWZpbmVkOlxuICAgICAgaWYgKHR5cGVvZiBmaWx0ZXIgPT09ICdzdHJpbmcnKSB7XG4gICAgICAgIHJldHVybiB0cmFuc2xhdGVVc2VycWxUb0NxbChcIidcIiArIGZpbHRlci5yZXBsYWNlKC8nL2csIFwiJydcIikgKyBcIidcIilcbiAgICAgIH0gZWxzZSBpZiAodHlwZW9mIGZpbHRlciA9PT0gJ251bWJlcicpIHtcbiAgICAgICAgcmV0dXJuIFN0cmluZyhmaWx0ZXIpXG4gICAgICB9IGVsc2UgaWYgKHR5cGVvZiBmaWx0ZXIgPT09ICdib29sZWFuJykge1xuICAgICAgICByZXR1cm4gQm9vbGVhbihmaWx0ZXIpXG4gICAgICB9XG4gICAgICBicmVha1xuICAgIGRlZmF1bHQ6XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJDYW4ndCBlbmNvZGU6IFwiICsgZmlsdGVyLnR5cGUgKyAnICcgKyBmaWx0ZXIpXG4gIH1cbn1cblxuZnVuY3Rpb24gc2ltcGxpZnlGaWx0ZXJzKGNxbEFzdDogRmlsdGVyQnVpbGRlckNsYXNzKSB7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgY3FsQXN0LmZpbHRlcnMubGVuZ3RoOyBpKyspIHtcbiAgICBpZiAoc2ltcGxpZnlBc3QoY3FsQXN0LmZpbHRlcnNbaV0sIGNxbEFzdCkpIHtcbiAgICAgIGNxbEFzdC5maWx0ZXJzLnNwbGljZS5hcHBseShcbiAgICAgICAgY3FsQXN0LmZpbHRlcnMsXG4gICAgICAgIChbaSwgMV0gYXMgYW55W10pLmNvbmNhdChcbiAgICAgICAgICAoY3FsQXN0LmZpbHRlcnNbaV0gYXMgRmlsdGVyQnVpbGRlckNsYXNzKS5maWx0ZXJzXG4gICAgICAgIClcbiAgICAgIClcbiAgICB9XG4gIH1cbiAgcmV0dXJuIGNxbEFzdFxufVxuXG4vKipcbiAqIFRoZSBjdXJyZW50IHJlYWQgZnVuY3Rpb24gZm9yIGNxbCBwcm9kdWNlcyBhbiB1bm9wdGltaXplZCB0cmVlLiAgV2hpbGUgaXQncyBwb3NzaWJsZSB3ZSBjb3VsZFxuICogZml4IHRoZSBvdXRwdXQgdGhlcmUsIEknbSBub3Qgc3VyZSBvZiBob3cuICBJdCBlbmRzIHVwIHByb2R1Y2luZyB2ZXJ5IG5lc3RlZCBmaWx0ZXIgdHJlZXMgZnJvbVxuICogcmVsYXRpdmVseSBzaW1wbGUgY3FsLlxuICogQHBhcmFtIGNxbEFzdFxuICogQHBhcmFtIHBhcmVudE5vZGVcbiAqL1xuZnVuY3Rpb24gc2ltcGxpZnlBc3QoXG4gIGNxbEFzdDogRmlsdGVyQnVpbGRlckNsYXNzIHwgRmlsdGVyQ2xhc3MsXG4gIHBhcmVudE5vZGU/OiBGaWx0ZXJCdWlsZGVyQ2xhc3Ncbikge1xuICBpZiAoIWlzRmlsdGVyQnVpbGRlckNsYXNzKGNxbEFzdCkgJiYgcGFyZW50Tm9kZSkge1xuICAgIHJldHVybiBmYWxzZVxuICB9IGVsc2UgaWYgKCFwYXJlbnROb2RlKSB7XG4gICAgaWYgKGlzRmlsdGVyQnVpbGRlckNsYXNzKGNxbEFzdCkpIHtcbiAgICAgIHNpbXBsaWZ5RmlsdGVycyhjcWxBc3QpXG4gICAgfVxuICAgIHJldHVybiBjcWxBc3RcbiAgfSBlbHNlIHtcbiAgICBzaW1wbGlmeUZpbHRlcnMoY3FsQXN0IGFzIEZpbHRlckJ1aWxkZXJDbGFzcylcbiAgICBpZiAoY3FsQXN0LnR5cGUgPT09IHBhcmVudE5vZGUudHlwZSAmJiAhY3FsQXN0Lm5lZ2F0ZWQpIHtcbiAgICAgIC8vIHRoZXNlIGFyZSB0aGUgb25seSBzaW1wbGlmaWNhdGlvbnMgd2UgY2FuIG1ha2UgYmFzZWQgb24gYm9vbGVhbiBhbGdlYnJhIHJ1bGVzXG4gICAgICByZXR1cm4gdHJ1ZVxuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gZmFsc2VcbiAgICB9XG4gIH1cbn1cblxuZnVuY3Rpb24gdW5jb2xsYXBzZU5PVHMoe1xuICBjcWxBc3QsXG59OiB7XG4gIGNxbEFzdDogRmlsdGVyQnVpbGRlckNsYXNzIHwgRmlsdGVyQ2xhc3Ncbn0pOiBDUUxTdGFuZGFyZEZpbHRlckJ1aWxkZXJDbGFzcyB8IEZpbHRlckNsYXNzIHtcbiAgaWYgKGlzRmlsdGVyQnVpbGRlckNsYXNzKGNxbEFzdCkpIHtcbiAgICBpZiAoY3FsQXN0Lm5lZ2F0ZWQpIHtcbiAgICAgIHJldHVybiBuZXcgQ1FMU3RhbmRhcmRGaWx0ZXJCdWlsZGVyQ2xhc3Moe1xuICAgICAgICB0eXBlOiAnTk9UJyxcbiAgICAgICAgZmlsdGVyczogW1xuICAgICAgICAgIG5ldyBDUUxTdGFuZGFyZEZpbHRlckJ1aWxkZXJDbGFzcyh7XG4gICAgICAgICAgICB0eXBlOiBjcWxBc3QudHlwZSxcbiAgICAgICAgICAgIGZpbHRlcnM6IGNxbEFzdC5maWx0ZXJzLm1hcCgoZmlsdGVyKSA9PlxuICAgICAgICAgICAgICB1bmNvbGxhcHNlTk9Ucyh7IGNxbEFzdDogZmlsdGVyIH0pXG4gICAgICAgICAgICApLFxuICAgICAgICAgIH0pLFxuICAgICAgICBdLFxuICAgICAgfSlcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIG5ldyBDUUxTdGFuZGFyZEZpbHRlckJ1aWxkZXJDbGFzcyh7XG4gICAgICAgIHR5cGU6IGNxbEFzdC50eXBlLFxuICAgICAgICBmaWx0ZXJzOiBjcWxBc3QuZmlsdGVycy5tYXAoKGZpbHRlcikgPT5cbiAgICAgICAgICB1bmNvbGxhcHNlTk9Ucyh7IGNxbEFzdDogZmlsdGVyIH0pXG4gICAgICAgICksXG4gICAgICB9KVxuICAgIH1cbiAgfSBlbHNlIHtcbiAgICBpZiAoY3FsQXN0Lm5lZ2F0ZWQpIHtcbiAgICAgIGNvbnN0IGNsb25lZEZpZWxkRmlsdGVyID0gX2Nsb25lRGVlcChjcWxBc3QpXG4gICAgICByZXR1cm4gbmV3IENRTFN0YW5kYXJkRmlsdGVyQnVpbGRlckNsYXNzKHtcbiAgICAgICAgdHlwZTogJ05PVCcsXG4gICAgICAgIGZpbHRlcnM6IFtcbiAgICAgICAgICBuZXcgQ1FMU3RhbmRhcmRGaWx0ZXJCdWlsZGVyQ2xhc3Moe1xuICAgICAgICAgICAgdHlwZTogJ0FORCcsXG4gICAgICAgICAgICBmaWx0ZXJzOiBbXG4gICAgICAgICAgICAgIG5ldyBGaWx0ZXJDbGFzcyh7XG4gICAgICAgICAgICAgICAgLi4uY2xvbmVkRmllbGRGaWx0ZXIsXG4gICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgXSxcbiAgICAgICAgICB9KSxcbiAgICAgICAgXSxcbiAgICAgIH0pXG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiBjcWxBc3RcbiAgICB9XG4gIH1cbn1cblxuZnVuY3Rpb24gZ2V0RGF0YVR5cGVzQ29uZmlndXJhdGlvblVzaW5nU3RhcnR1cFN0b3JlKCkge1xuICByZXR1cm4gZ2V0RGF0YVR5cGVzQ29uZmlndXJhdGlvbih7XG4gICAgQ29uZmlndXJhdGlvbjogU3RhcnR1cERhdGFTdG9yZS5Db25maWd1cmF0aW9uLFxuICAgIE1ldGFjYXJkRGVmaW5pdGlvbnM6IFN0YXJ0dXBEYXRhU3RvcmUuTWV0YWNhcmREZWZpbml0aW9ucyxcbiAgfSlcbn1cblxuZnVuY3Rpb24gaGFuZGxlQWxsRmlsdGVyVHlwZXMoXG4gIGNxbEFzdDogRmlsdGVyQnVpbGRlckNsYXNzIHwgRmlsdGVyQ2xhc3MgfCBDUUxTdGFuZGFyZEZpbHRlckJ1aWxkZXJDbGFzc1xuKTogQ1FMU3RhbmRhcmRGaWx0ZXJCdWlsZGVyQ2xhc3MgfCBGaWx0ZXJDbGFzcyB7XG4gIGNvbnN0IGV4dHJhRmlsdGVyQ2xhc3MgPSBFeHRlbnNpb25zLmV4dHJhRmlsdGVyc1xuICAgID8gRXh0ZW5zaW9ucy5leHRyYUZpbHRlcnMuZmlsdGVyVHlwZXNIYW5kbGVyKGNxbEFzdClcbiAgICA6IG51bGxcbiAgaWYgKGlzQ1FMU3RhbmRhcmRGaWx0ZXJCdWlsZGVyQ2xhc3MoY3FsQXN0KSB8fCBpc0ZpbHRlckJ1aWxkZXJDbGFzcyhjcWxBc3QpKSB7XG4gICAgcmV0dXJuIG5ldyBDUUxTdGFuZGFyZEZpbHRlckJ1aWxkZXJDbGFzcyh7XG4gICAgICB0eXBlOiBjcWxBc3QudHlwZSxcbiAgICAgIGZpbHRlcnM6IGNxbEFzdC5maWx0ZXJzLm1hcCgoZmlsdGVyKSA9PiBoYW5kbGVBbGxGaWx0ZXJUeXBlcyhmaWx0ZXIpKSxcbiAgICB9KVxuICB9IGVsc2UgaWYgKGlzQmFzaWNEYXRhdHlwZUNsYXNzKGNxbEFzdCkpIHtcbiAgICBjb25zdCBkYXRhVHlwZUNvbmZpZ3VyYXRpb24gPSBnZXREYXRhVHlwZXNDb25maWd1cmF0aW9uVXNpbmdTdGFydHVwU3RvcmUoKVxuICAgIGNvbnN0IGRhdGF0eXBlRmlsdGVyczogRmlsdGVyQ2xhc3NbXSA9IFtdXG4gICAgY3FsQXN0LnZhbHVlLm1hcCgodmFsdWUpID0+IHtcbiAgICAgIGNvbnN0IHJlbGV2YW50QXR0cmlidXRlcyA9IGRhdGFUeXBlQ29uZmlndXJhdGlvbi52YWx1ZU1hcFt2YWx1ZV1cbiAgICAgIGlmIChyZWxldmFudEF0dHJpYnV0ZXMpIHtcbiAgICAgICAgT2JqZWN0LmtleXMocmVsZXZhbnRBdHRyaWJ1dGVzLmF0dHJpYnV0ZXMpLm1hcCgoYXR0cmlidXRlKSA9PiB7XG4gICAgICAgICAgY29uc3QgcmVsZXZhbnRWYWx1ZXMgPSByZWxldmFudEF0dHJpYnV0ZXMuYXR0cmlidXRlc1thdHRyaWJ1dGVdXG4gICAgICAgICAgcmVsZXZhbnRWYWx1ZXMuZm9yRWFjaCgocmVsZXZhbnRWYWx1ZSkgPT4ge1xuICAgICAgICAgICAgZGF0YXR5cGVGaWx0ZXJzLnB1c2goXG4gICAgICAgICAgICAgIG5ldyBGaWx0ZXJDbGFzcyh7XG4gICAgICAgICAgICAgICAgcHJvcGVydHk6IGF0dHJpYnV0ZSxcbiAgICAgICAgICAgICAgICB2YWx1ZTogcmVsZXZhbnRWYWx1ZSxcbiAgICAgICAgICAgICAgICB0eXBlOiAnSUxJS0UnLFxuICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgKVxuICAgICAgICAgIH0pXG4gICAgICAgIH0pXG4gICAgICB9XG4gICAgfSlcbiAgICByZXR1cm4gbmV3IENRTFN0YW5kYXJkRmlsdGVyQnVpbGRlckNsYXNzKHtcbiAgICAgIHR5cGU6ICdBTkQnLFxuICAgICAgZmlsdGVyczogW1xuICAgICAgICBuZXcgQ1FMU3RhbmRhcmRGaWx0ZXJCdWlsZGVyQ2xhc3Moe1xuICAgICAgICAgIHR5cGU6ICdPUicsXG4gICAgICAgICAgZmlsdGVyczogZGF0YXR5cGVGaWx0ZXJzLFxuICAgICAgICB9KSxcbiAgICAgIF0sXG4gICAgfSlcbiAgfSBlbHNlIGlmIChleHRyYUZpbHRlckNsYXNzKSB7XG4gICAgcmV0dXJuIGV4dHJhRmlsdGVyQ2xhc3NcbiAgfSBlbHNlIGlmIChpc1Jlc291cmNlU2l6ZUZpbHRlckNsYXNzKGNxbEFzdCkpIHtcbiAgICBjb25zdCBieXRlc1ZhbHVlID0gY29udmVydFJlc291cmNlU2l6ZUZpbHRlckNsYXNzVmFsdWVUb0J5dGVzKGNxbEFzdClcbiAgICByZXR1cm4gbmV3IEZpbHRlckNsYXNzKHtcbiAgICAgIC4uLmNxbEFzdCxcbiAgICAgIHZhbHVlOiBieXRlc1ZhbHVlLFxuICAgIH0pXG4gIH0gZWxzZSBpZiAoaXNSZXNvdXJjZVNpemVSYW5nZUZpbHRlckNsYXNzKGNxbEFzdCkpIHtcbiAgICBjb25zdCBieXRlc1ZhbHVlID0gY29udmVydFJlc291cmNlU2l6ZVJhbmdlRmlsdGVyQ2xhc3NWYWx1ZVRvQnl0ZXMoY3FsQXN0KVxuICAgIHJldHVybiBuZXcgRmlsdGVyQ2xhc3Moe1xuICAgICAgLi4uY3FsQXN0LFxuICAgICAgdmFsdWU6IGJ5dGVzVmFsdWUsXG4gICAgfSlcbiAgfSBlbHNlIHtcbiAgICByZXR1cm4gY3FsQXN0XG4gIH1cbn1cblxuLyoqXG4gKiBGb3Igbm93LCBhbGwgdGhpcyBkb2VzIGlzIHJlbW92ZSBhbnlEYXRlIGZyb20gY3FsIHNpbmNlIHRoYXQncyBwdXJlbHkgZm9yIHRoZSBVSSB0byB0cmFjayB0aGUgcXVlcnkgYmFzaWMgdmlldyBzdGF0ZSBjb3JyZWN0bHkuXG4gKiBXZSBtaWdodCB3YW50IHRvIHJlY29uc2lkZXIgaG93IHdlIGRvIHRoZSBiYXNpYyBxdWVyeSBpbiBvcmRlciB0byBhdm9pZCB0aGlzIG5lY2Vzc2l0eSAoaXQncyByZWFsbHkgdGhlIGNoZWNrYm94KS5cbiAqXG4gKiBUaGlzIHdpbGwgb25seSBldmVyIGhhcHBlbiB3aXRoIGEgc3BlY2lmaWMgc3RydWN0dXJlLCBzbyB3ZSBkb24ndCBuZWVkIHRvIHJlY3Vyc2Ugb3IgYW55dGhpbmcuXG4gKi9cbmZ1bmN0aW9uIHJlbW92ZUludmFsaWRGaWx0ZXJzKFxuICBjcWxBc3Q6IEZpbHRlckJ1aWxkZXJDbGFzcyB8IEZpbHRlckNsYXNzIHwgQ1FMU3RhbmRhcmRGaWx0ZXJCdWlsZGVyQ2xhc3Ncbik6IEZpbHRlckJ1aWxkZXJDbGFzcyB8IEZpbHRlckNsYXNzIHwgYm9vbGVhbiB8IENRTFN0YW5kYXJkRmlsdGVyQnVpbGRlckNsYXNzIHtcbiAgLy8gbG9vcCBvdmVyIGZpbHRlcnMsIHNwbGljaW5nIG91dCBpbnZhbGlkIG9uZXMsIGF0IGVuZCBvZiBsb29wIGlmIGFsbCBmaWx0ZXJzIGdvbmUsIHJlbW92ZSBzZWxmP1xuICBpZiAoXG4gICAgaXNGaWx0ZXJCdWlsZGVyQ2xhc3MoY3FsQXN0KSB8fFxuICAgIHNob3VsZEJlRmlsdGVyQnVpbGRlckNsYXNzKGNxbEFzdCkgfHxcbiAgICBpc0NRTFN0YW5kYXJkRmlsdGVyQnVpbGRlckNsYXNzKGNxbEFzdClcbiAgKSB7XG4gICAgbGV0IGkgPSBjcWxBc3QuZmlsdGVycy5sZW5ndGhcbiAgICB3aGlsZSAoaS0tKSB7XG4gICAgICBjb25zdCBjdXJyZW50RmlsdGVyID0gY3FsQXN0LmZpbHRlcnNbaV1cbiAgICAgIGNvbnN0IHZhbGlkRmlsdGVyID0gcmVtb3ZlSW52YWxpZEZpbHRlcnMoY3VycmVudEZpbHRlcilcbiAgICAgIGlmICghdmFsaWRGaWx0ZXIpIHtcbiAgICAgICAgY3FsQXN0LmZpbHRlcnMuc3BsaWNlKGksIDEpXG4gICAgICB9XG4gICAgfVxuICAgIGlmIChjcWxBc3QuZmlsdGVycy5sZW5ndGggPT09IDApIHtcbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH1cbiAgfSBlbHNlIHtcbiAgICBpZiAoY3FsQXN0LnByb3BlcnR5ID09PSAnYW55RGF0ZScpIHtcbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH1cbiAgICBpZiAoY3FsQXN0LnR5cGUgPT09ICdCT09MRUFOX1RFWFRfU0VBUkNIJykge1xuICAgICAgY29uc3QgYm9vbGVhblRleHRWYWx1ZSA9IGNxbEFzdC52YWx1ZSBhcyBCb29sZWFuVGV4dFR5cGVcbiAgICAgIGlmIChib29sZWFuVGV4dFZhbHVlLmVycm9yKSB7XG4gICAgICAgIHJldHVybiBmYWxzZVxuICAgICAgfVxuICAgIH1cbiAgfVxuICByZXR1cm4gY3FsQXN0XG59XG5cbmZ1bmN0aW9uIGl0ZXJhdGl2ZWx5U2ltcGxpZnkoY3FsQXN0OiBGaWx0ZXJCdWlsZGVyQ2xhc3MpIHtcbiAgbGV0IHByZXZBc3QgPSBfY2xvbmVEZWVwKGNxbEFzdClcbiAgc2ltcGxpZnlBc3QoY3FsQXN0KVxuICB3aGlsZSAoSlNPTi5zdHJpbmdpZnkocHJldkFzdCkgIT09IEpTT04uc3RyaW5naWZ5KGNxbEFzdCkpIHtcbiAgICBwcmV2QXN0ID0gX2Nsb25lRGVlcChjcWxBc3QpXG4gICAgc2ltcGxpZnlBc3QoY3FsQXN0KVxuICB9XG4gIHJldHVybiBjcWxBc3Rcbn1cblxuZXhwb3J0IGRlZmF1bHQge1xuICAvKipcbiAgICogVGhpcyBmdW5jdGlvbiBzaG91bGQgYmUgdXNlZCBvbmx5IHRvIHRlc3QgcmVjb25zdGl0dXRpb24sIG9yIGFzIGEgbGFzdCByZXNvcnQgdG8gaGFuZGxlIHVwZ3JhZGVzIGZyb20gYSBzeXN0ZW0gd2hlcmUgdGhlIGZpbHRlciB0cmVlIGlzXG4gICAqIG5vIGxvbmdlciBjb21wYXRpYmxlLiAgTm8gbG9zcyBvZiBhY2N1cmFjeSB3aWxsIG9jY3VyLCBidXQgbmljZSBVWCB0b3VjaGVzIGxpa2UgcmVtZW1iZXJpbmcgY29vcmRpbmF0ZSBzeXN0ZW1zIGFuZCB1bml0cyB3aWxsLlxuICAgKlxuICAgKiBBbHNvLCBpdCBtYXkgZ3JvdXAgdGhpbmdzIHNsaWdodGx5IGRpZmZlcmVudCAod2UgZG8gb3VyIGJlc3QgZWZmb3J0LCBidXQgdGhlIHBvc3RmaXggbm90YXRpb24gdGVjaG5pY2FsbHkgY2F1c2VzIHBhcmVucyBhcm91bmQgZXZlcnl0aGluZywgYW5kIGZyb20gdGhlcmVcbiAgICogd2UgZG8gYSBzaW1wbGlmaWNhdGlvbiwgd2hpY2ggbWVhbnMgdGhlIHJlc3VsdGluZyBmaWx0ZXIgdHJlZSBtYXkgbG9vayBzaW1wbGVyIHRoYW4geW91IHJlbWVtYmVyKS4gIEhvd2V2ZXIsIG9uY2UgYWdhaW4sIHRoZSBhY2N1cmFjeSBhbmRcbiAgICogcmVzdWx0cyByZXR1cm5lZCBieSB0aGUgc2VhcmNoIHdpbGwgcmVtYWluIHRoZSBzYW1lLlxuICAgKiBAcGFyYW0gY3FsXG4gICAqL1xuICByZWFkKGNxbD86IHN0cmluZyk6IEZpbHRlckJ1aWxkZXJDbGFzcyB7XG4gICAgaWYgKGNxbCA9PT0gdW5kZWZpbmVkIHx8IGNxbC5sZW5ndGggPT09IDApIHtcbiAgICAgIHJldHVybiBuZXcgRmlsdGVyQnVpbGRlckNsYXNzKHtcbiAgICAgICAgdHlwZTogJ0FORCcsXG4gICAgICAgIGZpbHRlcnM6IFtdLFxuICAgICAgfSlcbiAgICB9XG4gICAgLy8gaWYgYW55dGhpbmcgZ29lcyB3cm9uZywgc2ltcGx5IGxvZyB0aGUgZXJyb3IgYW5kIG1vdmUgb24gKHJldHVybiBhIGRlZmF1bHQgZmlsdGVyIHRyZWUpLlxuICAgIHRyeSB7XG4gICAgICBjb25zdCByZWNvbnN0cnVjdGVkRmlsdGVyID0gdGhpcy5zaW1wbGlmeShidWlsZEFzdCh0b2tlbml6ZShjcWwpKSlcbiAgICAgIGlmIChcbiAgICAgICAgaXNGaWx0ZXJCdWlsZGVyQ2xhc3MocmVjb25zdHJ1Y3RlZEZpbHRlcikgfHxcbiAgICAgICAgc2hvdWxkQmVGaWx0ZXJCdWlsZGVyQ2xhc3MocmVjb25zdHJ1Y3RlZEZpbHRlcilcbiAgICAgICkge1xuICAgICAgICByZXR1cm4gbmV3IEZpbHRlckJ1aWxkZXJDbGFzcyhyZWNvbnN0cnVjdGVkRmlsdGVyKVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIG5ldyBGaWx0ZXJCdWlsZGVyQ2xhc3Moe1xuICAgICAgICAgIHR5cGU6ICdBTkQnLFxuICAgICAgICAgIGZpbHRlcnM6IFtyZWNvbnN0cnVjdGVkRmlsdGVyIGFzIEZpbHRlckNsYXNzXSxcbiAgICAgICAgfSlcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKVxuICAgICAgcmV0dXJuIG5ldyBGaWx0ZXJCdWlsZGVyQ2xhc3MoeyB0eXBlOiAnQU5EJywgZmlsdGVyczogW10gfSlcbiAgICB9XG4gIH0sXG4gIHdyaXRlKGZpbHRlcjogRmlsdGVyQnVpbGRlckNsYXNzKTogc3RyaW5nIHtcbiAgICB0cnkge1xuICAgICAgY29uc3Qgc3RhbmRhcmRDcWxBc3QgPSBoYW5kbGVBbGxGaWx0ZXJUeXBlcyhcbiAgICAgICAgdW5jb2xsYXBzZU5PVHMoe1xuICAgICAgICAgIGNxbEFzdDogZmlsdGVyLFxuICAgICAgICB9KVxuICAgICAgKVxuICAgICAgcmVtb3ZlSW52YWxpZEZpbHRlcnMoc3RhbmRhcmRDcWxBc3QpXG4gICAgICByZXR1cm4gd3JpdGUoc3RhbmRhcmRDcWxBc3QpXG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGVycilcbiAgICAgIHJldHVybiB3cml0ZShcbiAgICAgICAgbmV3IEZpbHRlckJ1aWxkZXJDbGFzcyh7XG4gICAgICAgICAgdHlwZTogJ0FORCcsXG4gICAgICAgICAgZmlsdGVyczogW10sXG4gICAgICAgIH0pXG4gICAgICApXG4gICAgfVxuICB9LFxuICByZW1vdmVJbnZhbGlkRmlsdGVycyxcbiAgc2ltcGxpZnkoY3FsQXN0OiBGaWx0ZXJCdWlsZGVyQ2xhc3MpOiBGaWx0ZXJCdWlsZGVyQ2xhc3Mge1xuICAgIHJldHVybiBpdGVyYXRpdmVseVNpbXBsaWZ5KGNxbEFzdClcbiAgfSxcbiAgdHJhbnNsYXRlQ3FsVG9Vc2VycWwsXG4gIHRyYW5zbGF0ZVVzZXJxbFRvQ3FsLFxuICBBTllURVhUX1dJTERDQVJELFxuICBnZXRHZW9GaWx0ZXJzLFxufVxuIl19